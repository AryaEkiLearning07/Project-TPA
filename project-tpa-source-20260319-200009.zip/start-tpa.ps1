$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$logFile = Join-Path $projectRoot 'dev-runtime.log'

$frontendPort = Get-NetTCPConnection -State Listen -LocalPort 5173 -ErrorAction SilentlyContinue
$backendPort = Get-NetTCPConnection -State Listen -LocalPort 4000 -ErrorAction SilentlyContinue

if ($frontendPort -and $backendPort) {
  Write-Output 'TPA runtime sudah berjalan (5173 & 4000 aktif).'
  exit 0
}

$existingStarter = Get-CimInstance Win32_Process |
  Where-Object {
    $_.Name -eq 'cmd.exe' -and
    $_.CommandLine -match [regex]::Escape("$projectRoot && npm run dev")
  }

if (-not $existingStarter) {
  Start-Process -FilePath 'cmd.exe' `
    -ArgumentList "/c cd /d `"$projectRoot`" && npm run dev >> `"$logFile`" 2>&1" `
    -WindowStyle Hidden
}

Start-Sleep -Seconds 8

$frontendPort = Get-NetTCPConnection -State Listen -LocalPort 5173 -ErrorAction SilentlyContinue
$backendPort = Get-NetTCPConnection -State Listen -LocalPort 4000 -ErrorAction SilentlyContinue

if (-not ($frontendPort -and $backendPort)) {
  Write-Error 'Gagal menyalakan runtime TPA. Cek dev-runtime.log.'
}

Write-Output 'TPA runtime berhasil dinyalakan.'
