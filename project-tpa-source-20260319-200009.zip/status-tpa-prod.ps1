$ErrorActionPreference = 'Stop'

$frontendPortNumber = 4173
$backendPortNumber = 4000

$frontendPort = Get-NetTCPConnection -State Listen -LocalPort $frontendPortNumber -ErrorAction SilentlyContinue
$backendPort = Get-NetTCPConnection -State Listen -LocalPort $backendPortNumber -ErrorAction SilentlyContinue

Write-Output "Frontend preview ($frontendPortNumber): $([bool]$frontendPort)"
Write-Output "Backend node     ($backendPortNumber): $([bool]$backendPort)"

try {
  $localHealth = Invoke-WebRequest -Uri "http://127.0.0.1:$backendPortNumber/health" -UseBasicParsing -TimeoutSec 5
  Write-Output "Local backend health: $($localHealth.StatusCode)"
} catch {
  Write-Output 'Local backend health: DOWN'
}

try {
  $localFrontend = Invoke-WebRequest -Uri "http://127.0.0.1:$frontendPortNumber" -UseBasicParsing -TimeoutSec 5
  Write-Output "Local frontend preview: $($localFrontend.StatusCode)"
} catch {
  Write-Output 'Local frontend preview: DOWN'
}

