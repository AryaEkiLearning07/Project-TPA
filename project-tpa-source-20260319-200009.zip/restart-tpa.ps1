$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot

$projectProcesses = Get-CimInstance Win32_Process |
  Where-Object {
    ($_.Name -in @('cmd.exe', 'node.exe')) -and
    $_.CommandLine -match [regex]::Escape($projectRoot)
  }

foreach ($proc in $projectProcesses) {
  try {
    Stop-Process -Id $proc.ProcessId -Force -ErrorAction Stop
  } catch {
  }
}

Start-Sleep -Seconds 2

& (Join-Path $PSScriptRoot 'start-tpa.ps1')
