import {
  CalendarDays,
  CheckCircle2,
  Clock3,
  DoorOpen,
  ShieldCheck,
  LogOut,
  Menu,
} from 'lucide-react'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import Sidebar from '../../components/layout/Sidebar'
import BeritaAcaraPage from './berita-acara/BeritaAcaraPage'
import DataAnakPage from './data-anak/DataAnakPage'
import InventoriPage from './inventori/InventoriPage'
import KehadiranPage from './kehadiran/KehadiranPage'
import ObservasiPage from './observasi/ObservasiPage'
import {
  attendanceApi,
  incidentApi,
  observationApi,
  supplyInventoryApi,
  childApi,
  staffAttendanceApi,
} from '../../services/api'
import type {
  AppData,
  AuthUser,
  AttendanceRecord,
  AttendanceRecordInput,
  ChildProfile,
  ConfirmDialogOptions,
  IncidentReport,
  IncidentReportInput,
  ObservationRecord,
  ObservationRecordInput,
  StaffAttendanceStatus,
  SupplyInventoryItem,
  SupplyInventoryItemInput,
} from '../../types'
import { createEmptyAppData } from '../../utils/storage'
import {
  parseNavigationState,
  pushNavigationState,
  readNavigationState,
  replaceNavigationState,
} from '../../utils/browser-history'
import { useHideOnScroll } from '../../utils/useHideOnScroll'
import {
  type PetugasMenuKey,
  type PetugasDataSegment,
  type ConfirmDialogState,
  normalizeAttendanceRecord,
  normalizeIncidentReport,
  normalizeObservationRecord,
  getErrorMessage,
  formatTimeOnly,
  menuTitles,
  menuDataSegments,
  petugasMenus,
  isPetugasNavigationState,
  buildPetugasNavigationState,
} from './petugasHelpers'

interface PetugasSectionProps {
  user: AuthUser
  onLogout: () => Promise<void>
}

const WIB_TIMEZONE = 'Asia/Jakarta'
const ATTENDANCE_DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/
const PLATFORM_LOGO_SRC = `${import.meta.env.BASE_URL}logo_TPA.jpg`

const formatWibTime = (date: Date, withSeconds: boolean): string => {
  const formatter = new Intl.DateTimeFormat('en-GB', {
    timeZone: WIB_TIMEZONE,
    hour: '2-digit',
    minute: '2-digit',
    second: withSeconds ? '2-digit' : undefined,
    hour12: false,
  })

  return formatter.format(date)
}

const formatAttendanceModuleTime = (value: string | null | undefined): string => {
  if (!value) {
    return '-- : --'
  }

  const date = new Date(value)
  if (Number.isNaN(date.getTime())) {
    return '-- : --'
  }

  return formatWibTime(date, false)
}

const formatAttendanceModuleDate = (value: string | null | undefined): string => {
  let parsedDate: Date
  if (value && ATTENDANCE_DATE_PATTERN.test(value)) {
    const [year, month, day] = value.split('-').map(Number)
    parsedDate = new Date(Date.UTC(year, month - 1, day, 12))
  } else if (value) {
    parsedDate = new Date(value)
  } else {
    parsedDate = new Date()
  }

  if (Number.isNaN(parsedDate.getTime())) {
    parsedDate = new Date()
  }

  return new Intl.DateTimeFormat('id-ID', {
    timeZone: WIB_TIMEZONE,
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  })
    .format(parsedDate)
    .toUpperCase()
}

function PetugasSection({ user, onLogout }: PetugasSectionProps) {
  const [appData, setAppData] = useState<AppData>(() => createEmptyAppData())
  const appDataRef = useRef<AppData>(createEmptyAppData())
  const [activeMenu, setActiveMenu] = useState<PetugasMenuKey>('kehadiran')
  const [isSidebarOpen, setSidebarOpen] = useState(false)
  const [isLoading, setLoading] = useState(false)
  const [isSyncing, setSyncing] = useState(false)
  const [statusMessage, setStatusMessage] = useState<string | null>(null)
  const [attendanceStatus, setAttendanceStatus] = useState<StaffAttendanceStatus | null>(
    null,
  )
  const [attendanceError, setAttendanceError] = useState<string | null>(null)
  const [toastMessage, setToastMessage] = useState<string | null>(
    null,
  )
  const [isLoadingAttendance, setLoadingAttendance] = useState(true)
  const [attendanceAction, setAttendanceAction] = useState<'check-in' | 'check-out' | null>(
    null,
  )
  const [isAttendanceBannerExpanded, setAttendanceBannerExpanded] = useState(false)
  const [confirmDialog, setConfirmDialog] = useState<ConfirmDialogState | null>(null)
  const confirmResolveRef = useRef<((result: boolean) => void) | null>(null)
  const initialMenuRef = useRef<PetugasMenuKey>(activeMenu)
  const isApplyingNavigationHistoryRef = useRef(false)
  const hasInitializedNavigationHistoryRef = useRef(false)
  const isTopbarHidden = useHideOnScroll()
  const loadRequestIdRef = useRef(0)
  const loadedSegmentsRef = useRef<Set<PetugasDataSegment>>(new Set())
  const [clockNow, setClockNow] = useState(() => new Date())

  const closeConfirmDialog = (result: boolean) => {
    const resolve = confirmResolveRef.current
    confirmResolveRef.current = null
    setConfirmDialog(null)
    if (resolve) {
      resolve(result)
    }
  }

  const requestConfirm = (options: ConfirmDialogOptions): Promise<boolean> =>
    new Promise((resolve) => {
      if (confirmResolveRef.current) {
        confirmResolveRef.current(false)
      }
      confirmResolveRef.current = resolve
      setConfirmDialog({
        title: options.title ?? 'Konfirmasi',
        message: options.message,
        confirmLabel: options.confirmLabel ?? 'Ya, Lanjutkan',
        cancelLabel: options.cancelLabel ?? 'Batal',
        tone: options.tone ?? 'default',
      })
    })

  useEffect(() => {
    appDataRef.current = appData
  }, [appData])

  useEffect(() => {
    const restoredState = readNavigationState(isPetugasNavigationState)

    if (restoredState) {
      if (restoredState.menu !== initialMenuRef.current) {
        isApplyingNavigationHistoryRef.current = true
        setActiveMenu(restoredState.menu)
      }
    } else {
      replaceNavigationState(buildPetugasNavigationState(initialMenuRef.current))
    }

    hasInitializedNavigationHistoryRef.current = true

    const handlePopState = (event: PopStateEvent) => {
      const nextState = parseNavigationState(event.state, isPetugasNavigationState)
      if (!nextState) {
        return
      }

      isApplyingNavigationHistoryRef.current = true
      setActiveMenu(nextState.menu)
      setSidebarOpen(false)
    }

    window.addEventListener('popstate', handlePopState)
    return () => {
      window.removeEventListener('popstate', handlePopState)
    }
  }, [])

  useEffect(() => {
    if (!hasInitializedNavigationHistoryRef.current) {
      return
    }

    if (isApplyingNavigationHistoryRef.current) {
      isApplyingNavigationHistoryRef.current = false
      return
    }

    const currentState = readNavigationState(isPetugasNavigationState)
    if (currentState?.menu === activeMenu) {
      return
    }

    pushNavigationState(buildPetugasNavigationState(activeMenu))
  }, [activeMenu])

  const loadAttendanceStatus = async (
    options?: { silent?: boolean },
  ): Promise<void> => {
    if (!options?.silent) {
      setLoadingAttendance(true)
    }

    try {
      const status = await staffAttendanceApi.getStatus()
      setAttendanceStatus(status)
      setAttendanceError(null)
    } catch (error) {
      setAttendanceError(`Gagal memuat status absensi: ${getErrorMessage(error)} `)
    } finally {
      if (!options?.silent) {
        setLoadingAttendance(false)
      }
    }
  }

  const loadMenuData = useCallback(
    async (
      menu: PetugasMenuKey,
      options?: { manualReload?: boolean },
    ): Promise<void> => {
      const requestId = ++loadRequestIdRef.current
      const requiredSegments = menuDataSegments[menu]
      const segmentsToFetch = options?.manualReload
        ? requiredSegments
        : requiredSegments.filter((segment) => !loadedSegmentsRef.current.has(segment))

      if (segmentsToFetch.length === 0) {
        if (requestId === loadRequestIdRef.current) {
          setLoading(false)
          setStatusMessage(null)
        }
        return
      }

      setLoading(true)

      try {
        const segments = new Set(segmentsToFetch)
        const [children, attendanceRecords, incidentReports, observationRecords, supplyInventory] =
          await Promise.all([
            segments.has('children') ? childApi.getChildren() : Promise.resolve<ChildProfile[] | null>(null),
            segments.has('attendanceRecords')
              ? attendanceApi.getAttendanceRecords()
              : Promise.resolve<AttendanceRecord[] | null>(null),
            segments.has('incidentReports')
              ? incidentApi.getIncidentReports()
              : Promise.resolve<IncidentReport[] | null>(null),
            segments.has('observationRecords')
              ? observationApi.getObservationRecords()
              : Promise.resolve<ObservationRecord[] | null>(null),
            segments.has('supplyInventory')
              ? supplyInventoryApi.getSupplyInventory()
              : Promise.resolve<SupplyInventoryItem[] | null>(null),
          ])

        if (requestId !== loadRequestIdRef.current) {
          return
        }

        segmentsToFetch.forEach((segment) => {
          loadedSegmentsRef.current.add(segment)
        })

        setAppData((previous) => {
          const nextState: AppData = {
            ...previous,
            ...(children ? { children } : {}),
            ...(attendanceRecords
              ? { attendanceRecords: attendanceRecords.map(normalizeAttendanceRecord) }
              : {}),
            ...(incidentReports
              ? { incidentReports: incidentReports.map(normalizeIncidentReport) }
              : {}),
            ...(observationRecords
              ? { observationRecords: observationRecords.map(normalizeObservationRecord) }
              : {}),
            ...(supplyInventory ? { supplyInventory } : {}),
          }
          appDataRef.current = nextState
          return nextState
        })

        if (options?.manualReload) {
          setStatusMessage(`Data "${menuTitles[menu].title}" berhasil dimuat ulang.`)
        } else {
          setStatusMessage(null)
        }
      } catch (error) {
        if (requestId !== loadRequestIdRef.current) {
          return
        }

        const menuLabel = menuTitles[menu].title.toLowerCase()
        setStatusMessage(`Gagal memuat data ${menuLabel}: ${getErrorMessage(error)} `)
      } finally {
        if (requestId === loadRequestIdRef.current) {
          setLoading(false)
        }
      }
    },
    [],
  )

  useEffect(() => {
    void loadAttendanceStatus()
  }, [])

  useEffect(() => {
    if (!attendanceStatus?.hasCheckedIn) {
      loadRequestIdRef.current += 1
      loadedSegmentsRef.current.clear()
      setLoading(false)
      setSyncing(false)
      setStatusMessage(null)
      return
    }

    void loadMenuData(activeMenu)
  }, [activeMenu, attendanceStatus?.hasCheckedIn, loadMenuData])

  useEffect(() => {
    if (!attendanceStatus?.hasCheckedIn || activeMenu !== 'kehadiran') {
      setAttendanceBannerExpanded(false)
    }
  }, [activeMenu, attendanceStatus?.hasCheckedIn])

  useEffect(() => {
    if (!toastMessage) {
      return undefined
    }

    const timerId = window.setTimeout(() => {
      setToastMessage(null)
    }, 3000)

    return () => {
      window.clearTimeout(timerId)
    }
  }, [toastMessage])

  useEffect(() => {
    const intervalId = window.setInterval(() => {
      setClockNow(new Date())
    }, 1000)

    return () => {
      window.clearInterval(intervalId)
    }
  }, [])

  useEffect(() => {
    if (!confirmDialog) {
      return undefined
    }

    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        closeConfirmDialog(false)
      }
    }

    document.addEventListener('keydown', handleEscapeKey)
    return () => {
      document.removeEventListener('keydown', handleEscapeKey)
    }
  }, [confirmDialog])

  useEffect(
    () => () => {
      if (confirmResolveRef.current) {
        confirmResolveRef.current(false)
        confirmResolveRef.current = null
      }
    },
    [],
  )
  const upsertIncidentReport = async (
    input: IncidentReportInput,
    editingId?: string,
  ): Promise<boolean> => {
    setSyncing(true)
    try {
      let saved: IncidentReport
      if (editingId) {
        saved = await incidentApi.updateIncidentReport(editingId, input)
      } else {
        saved = await incidentApi.createIncidentReport(input)
      }

      setAppData((previous) => {
        const nextState = {
          ...previous,
          incidentReports: editingId
            ? previous.incidentReports.map((record) =>
              record.id === editingId ? saved : record,
            )
            : [saved, ...previous.incidentReports],
        }
        appDataRef.current = nextState
        return nextState
      })
      setStatusMessage(null)
      setToastMessage('Data berita acara berhasil disimpan.')
      return true
    } catch (error) {
      const message = getErrorMessage(error)
      setStatusMessage(`Gagal menyimpan berita acara: ${message} `)
      return false
    } finally {
      setSyncing(false)
    }
  }

  const upsertAttendanceRecord = async (
    input: AttendanceRecordInput,
    editingId?: string,
  ): Promise<boolean> => {
    setSyncing(true)
    try {
      let saved: AttendanceRecord
      if (editingId) {
        saved = await attendanceApi.updateAttendanceRecord(editingId, input)
      } else {
        saved = await attendanceApi.createAttendanceRecord(input)
      }

      setAppData((previous) => {
        const nextState = {
          ...previous,
          attendanceRecords: editingId
            ? previous.attendanceRecords.map((record) =>
              record.id === editingId ? saved : record,
            )
            : [saved, ...previous.attendanceRecords],
        }
        appDataRef.current = nextState
        return nextState
      })
      setStatusMessage(null)
      setToastMessage('Data kehadiran berhasil disimpan.')
      return true
    } catch (error) {
      const message = getErrorMessage(error)
      setStatusMessage(`Gagal menyimpan data absensi: ${message} `)
      return false
    } finally {
      setSyncing(false)
    }
  }

  const upsertSupplyInventoryItem = async (
    input: SupplyInventoryItemInput,
    editingId?: string,
  ): Promise<boolean> => {
    setSyncing(true)
    try {
      let saved: SupplyInventoryItem
      if (editingId) {
        saved = await supplyInventoryApi.updateSupplyItem(editingId, input)
      } else {
        saved = await supplyInventoryApi.createSupplyItem(input)
      }

      setAppData((previous) => {
        const nextState = {
          ...previous,
          supplyInventory: editingId
            ? previous.supplyInventory.map((record) =>
              record.id === editingId ? saved : record,
            )
            : [saved, ...previous.supplyInventory],
        }
        appDataRef.current = nextState
        return nextState
      })
      setStatusMessage(null)
      setToastMessage('Data inventori berhasil disimpan.')
      return true
    } catch (error) {
      const message = getErrorMessage(error)
      setStatusMessage(`Gagal menyimpan data inventori: ${message} `)
      return false
    } finally {
      setSyncing(false)
    }
  }

  const removeSupplyInventoryItem = async (id: string): Promise<boolean> => {
    setSyncing(true)
    try {
      await supplyInventoryApi.deleteSupplyItem(id)

      setAppData((previous) => {
        const nextState = {
          ...previous,
          supplyInventory: previous.supplyInventory.filter((record) => record.id !== id),
        }
        appDataRef.current = nextState
        return nextState
      })
      setStatusMessage(null)
      setToastMessage('Data inventori berhasil dihapus.')
      return true
    } catch (error) {
      const message = getErrorMessage(error)
      setStatusMessage(`Gagal menghapus data inventori: ${message} `)
      return false
    } finally {
      setSyncing(false)
    }
  }

  const upsertObservationRecord = async (
    input: ObservationRecordInput,
    editingId?: string,
  ): Promise<boolean> => {
    setSyncing(true)
    try {
      let saved: ObservationRecord
      if (editingId) {
        saved = await observationApi.updateObservationRecord(editingId, input)
      } else {
        saved = await observationApi.createObservationRecord(input)
      }

      setAppData((previous) => {
        const nextState = {
          ...previous,
          observationRecords: editingId
            ? previous.observationRecords.map((record) =>
              record.id === editingId ? saved : record,
            )
            : [saved, ...previous.observationRecords],
        }
        appDataRef.current = nextState
        return nextState
      })
      setStatusMessage(null)
      setToastMessage('Data observasi berhasil disimpan.')
      return true
    } catch (error) {
      const message = getErrorMessage(error)
      setStatusMessage(`Gagal menyimpan data observasi: ${message} `)
      return false
    } finally {
      setSyncing(false)
    }
  }

  const handleCheckIn = async () => {
    setAttendanceAction('check-in')
    setAttendanceError(null)
    setToastMessage(null)

    try {
      const result = await staffAttendanceApi.checkIn()
      setAttendanceStatus(result.status)
      setToastMessage(
        result.alreadyCheckedIn
          ? 'Absensi datang sudah tercatat hari ini.'
          : 'Absensi datang berhasil. Fitur operasional sudah dibuka.',
      )
    } catch (error) {
      setAttendanceError(`Gagal absensi datang: ${getErrorMessage(error)} `)
    } finally {
      setAttendanceAction(null)
    }
  }

  const handleCheckOut = async () => {
    setAttendanceAction('check-out')
    setAttendanceError(null)
    setToastMessage(null)

    try {
      const result = await staffAttendanceApi.checkOut()
      setAttendanceStatus(result.status)
      setToastMessage(
        result.alreadyCheckedOut
          ? 'Absensi pulang sudah tercatat hari ini.'
          : 'Absensi pulang berhasil.',
      )
    } catch (error) {
      setAttendanceError(`Gagal absensi pulang: ${getErrorMessage(error)} `)
    } finally {
      setAttendanceAction(null)
    }
  }

  const selectMenu = (menu: string) => {
    setActiveMenu(menu as PetugasMenuKey)
    setSidebarOpen(false)
  }

  const viewDataAnak = () => {
    setActiveMenu('data-anak')
    setSidebarOpen(false)
  }

  // Disabled: Attendance feature for petugas role
  // const canAccessOperationalFeatures = Boolean(attendanceStatus?.hasCheckedIn)
  const canAccessOperationalFeatures = true
  const canCheckOut =
    canAccessOperationalFeatures &&
    !attendanceStatus?.hasCheckedOut &&
    attendanceAction !== 'check-out'
  const activeHeader = useMemo(
    () =>
      canAccessOperationalFeatures
        ? menuTitles[activeMenu]
        : {
          title: 'Absensi Petugas',
          subtitle: 'Lakukan absensi datang sebelum mengakses fitur operasional.',
        },
    [activeMenu, canAccessOperationalFeatures],
  )
  const showLoadingOverlay = canAccessOperationalFeatures && isSyncing
  const isAttendanceGateMode = !canAccessOperationalFeatures
  const currentWibClockLabel = useMemo(() => formatWibTime(clockNow, true), [clockNow])
  const attendanceDateLabel = useMemo(() => {
    if (attendanceStatus?.attendanceDate) {
      return formatAttendanceModuleDate(attendanceStatus.attendanceDate)
    }

    return formatAttendanceModuleDate(clockNow.toISOString())
  }, [attendanceStatus?.attendanceDate, clockNow])
  const checkInLabel = useMemo(
    () => formatAttendanceModuleTime(attendanceStatus?.checkInAt),
    [attendanceStatus?.checkInAt],
  )
  const checkOutLabel = useMemo(
    () => formatAttendanceModuleTime(attendanceStatus?.checkOutAt),
    [attendanceStatus?.checkOutAt],
  )

  const renderPage = () => {
    switch (activeMenu) {
      case 'berita-acara':
        return (
          <BeritaAcaraPage
            childrenData={appData.children}
            reports={appData.incidentReports}
            attendanceRecords={appData.attendanceRecords}
            isTableLoading={isLoading}
            onSave={upsertIncidentReport}
            onNavigateToDataAnak={viewDataAnak}
          />
        )
      case 'kehadiran':
        return (
          <KehadiranPage
            childrenData={appData.children}
            records={appData.attendanceRecords}
            supplyItems={appData.supplyInventory}
            isTableLoading={isLoading}
            onSave={upsertAttendanceRecord}
            onNavigateToDataAnak={viewDataAnak}
          />
        )
      case 'observasi':
        return (
          <ObservasiPage
            childrenData={appData.children}
            records={appData.observationRecords}
            attendanceRecords={appData.attendanceRecords}
            showRecapSection={false}
            isTableLoading={isLoading}
            onSave={upsertObservationRecord}
            onNavigateToDataAnak={viewDataAnak}
          />
        )
      case 'inventori':
        return (
          <InventoriPage
            childrenData={appData.children}
            supplyItems={appData.supplyInventory}
            onSaveSupplyItem={upsertSupplyInventoryItem}
            onDeleteSupplyItem={removeSupplyInventoryItem}
            onRequestConfirm={requestConfirm}
          />
        )
      case 'data-anak':
      default:
        return (
          <DataAnakPage
            childrenData={appData.children}
            viewerRole="PETUGAS"
            canManageData={false}
            onRequestConfirm={requestConfirm}
          />
        )
    }
  }


  // Disabled: Attendance feature for petugas role

  const renderAttendanceGate = () => (
    <section className="page page--attendance-gate">
      <div className="card staff-attendance-hero">
        <div className="staff-attendance-hero__badge-block" aria-hidden="true">
          <div className="staff-attendance-hero__badge">
            <img src={PLATFORM_LOGO_SRC} alt="" className="staff-attendance-hero__logo" />
          </div>
          <p>OFFICER PRESENCE</p>
        </div>
        <div className="staff-attendance-hero__content">
          <h2>PRESENSI PETUGAS TERPADU</h2>
          <p>Lakukan absensi datang sebelum mengakses fitur operasional.</p>
        </div>
      </div>

      <div className="card staff-attendance-gate">
        <div className="staff-attendance-gate__header">
          <h3>ABSENSI HARI INI</h3>
          <div className="staff-attendance-clock" role="status" aria-live="polite">
            <Clock3 size={16} />
            <span>Waktu Sekarang: {currentWibClockLabel} WIB</span>
          </div>
        </div>

        <p className="staff-attendance-gate__description">
          Anda wajib absensi datang terlebih dahulu untuk membuka fitur operasional.
        </p>

        <div className="staff-attendance-meta">
          <article className="staff-attendance-module staff-attendance-module--date">
            <span className="staff-attendance-module__security" aria-hidden="true">
              <ShieldCheck size={14} />
            </span>
            <div className="staff-attendance-module__label">
              <CalendarDays size={16} />
              <span>Tanggal</span>
            </div>
            <strong>{attendanceDateLabel}</strong>
          </article>
          <article className="staff-attendance-module">
            <div className="staff-attendance-module__label">
              <Clock3 size={16} />
              <span>Absensi Datang</span>
            </div>
            <strong>{checkInLabel}</strong>
          </article>
          <article className="staff-attendance-module">
            <div className="staff-attendance-module__label">
              <LogOut size={16} />
              <span>Absensi Pulang</span>
            </div>
            <strong>{checkOutLabel}</strong>
          </article>
        </div>

        {attendanceError ? <p className="field-error">{attendanceError}</p> : null}
        <div className="form-actions staff-attendance-gate__actions">
          <button
            type="button"
            className="button button--attendance-checkin"
            onClick={() => void handleCheckIn()}
            disabled={attendanceAction === 'check-in' || isLoadingAttendance}
          >
            <CheckCircle2 size={18} />
            <span>{attendanceAction === 'check-in' ? 'Memproses...' : 'Absen Datang'}</span>
          </button>
          <button
            type="button"
            className="button button--attendance-logout"
            onClick={() => void onLogout()}
            disabled={attendanceAction !== null}
          >
            <LogOut size={18} />
            <span>Log Out</span>
          </button>
        </div>
      </div>
    </section>
  )

  const renderAttendanceBanner = () => {
    // Disabled: Attendance feature for petugas role
    if (!attendanceStatus || !canAccessOperationalFeatures || activeMenu !== 'kehadiran') {
      return null
    }

    const bannerToneClass = attendanceStatus.hasCheckedOut
      ? 'is-danger'
      : attendanceStatus.productivityStatus === 'aktif'
        ? 'is-active'
        : 'is-warning'

    return (
      <section className="page">
        <div
          id="tour-attendance-banner"
          className={`card staff-attendance-banner ${bannerToneClass} ${isAttendanceBannerExpanded ? 'is-expanded' : ''}`}
          role="button"
          tabIndex={0}
          onClick={() => setAttendanceBannerExpanded((previous) => !previous)}
          onKeyDown={(event) => {
            if (event.key === 'Enter' || event.key === ' ') {
              event.preventDefault()
              setAttendanceBannerExpanded((previous) => !previous)
            }
          }}
          aria-expanded={isAttendanceBannerExpanded}
        >
          <div className="staff-attendance-banner__summary">
            <p className="staff-attendance-banner__title">Status Absensi Hari Ini</p>
            <p className="staff-attendance-banner__desc">
              Jam datang: {formatTimeOnly(attendanceStatus.checkInAt)} | Jam pulang:{' '}
              {formatTimeOnly(attendanceStatus.checkOutAt)}
            </p>
            <p className="staff-attendance-banner__desc">
              Aktivitas input data: {attendanceStatus.productiveActivityCount} aktivitas
            </p>
            <p className="staff-attendance-banner__hint">
              Klik kartu untuk buka aksi.
            </p>
          </div>

          <div className="staff-attendance-banner__actions">
            {!attendanceStatus.hasCheckedOut ? (
              <button
                type="button"
                className="staff-attendance-action staff-attendance-action--checkout"
                onClick={(event) => {
                  event.stopPropagation()
                  void handleCheckOut()
                }}
                disabled={!canCheckOut}
                aria-label="Absen Pulang"
              >
                <DoorOpen size={16} className="staff-attendance-action__icon" />
                <span>{attendanceAction === 'check-out' ? 'Memproses...' : 'Absen Pulang'}</span>
              </button>
            ) : null}
          </div>
        </div>
      </section>
    )
  }


  return (
    <div className={`app-shell ${isAttendanceGateMode ? 'app-shell--attendance-gate' : ''}`.trim()}>
      {canAccessOperationalFeatures ? (
        <Sidebar
          activeMenu={activeMenu}
          menus={petugasMenus}
          isOpen={isSidebarOpen}
          onMenuSelect={selectMenu}
          onClose={() => setSidebarOpen(false)}
          onLogout={onLogout}
          userLabel={user.displayName}
          accountLabel="Pendamping Hari Ini"
          panelTitle="Panel Petugas"
          menuLabel="Menu Petugas"
          chipLabel=""
        />
      ) : null}

      <div className={`app-main ${isAttendanceGateMode ? 'app-main--attendance-gate' : ''}`.trim()}>
        {canAccessOperationalFeatures ? (
          <header className={`topbar ${isTopbarHidden ? 'is-hidden' : ''}`}>
            <button
              type="button"
              className="topbar__menu"
              onClick={() => setSidebarOpen(true)}
              aria-label="Buka menu"
            >
              <Menu size={18} />
            </button>
            <div id="tour-topbar-title" className="topbar__title-wrap">
              <h1>{activeHeader.title}</h1>
              <p>{activeHeader.subtitle}</p>
            </div>
          </header>
        ) : null}

        <main
          id="tour-main-content"
          className={`app-content ${isAttendanceGateMode ? 'app-content--attendance-gate' : ''}`.trim()}
        >
          {isLoadingAttendance ? (
            <section className="page">
              <div className="card">
                <p>Memuat status absensi petugas...</p>
              </div>
            </section>
          ) : canAccessOperationalFeatures ? (
            <>
              {renderAttendanceBanner()}
              {attendanceError ? (
                <section className="page">
                  <div className="card">
                    <p className="field-error">{attendanceError}</p>
                    <div className="form-actions">
                      <button
                        type="button"
                        className="button button--ghost"
                        onClick={() => void loadAttendanceStatus()}
                      >
                        Coba Lagi
                      </button>
                    </div>
                  </div>
                </section>
              ) : null}
              {statusMessage ? (
                <section className="page">
                  <div className="card">
                    <p>{statusMessage}</p>
                    {isSyncing ? <p className="field-hint">Sinkronisasi database...</p> : null}
                  </div>
                </section>
              ) : null}
              {renderPage()}
            </>
          ) : (
            renderAttendanceGate()
          )}
        </main>
      </div>

      {toastMessage ? (
        <div className="app-toast app-toast--success" role="status" aria-live="polite">
          <CheckCircle2 size={18} />
          <span>{toastMessage}</span>
        </div>
      ) : null}

      {confirmDialog ? (
        <div
          className="app-confirm-overlay"
          onClick={(event) => {
            if (event.target === event.currentTarget) {
              closeConfirmDialog(false)
            }
          }}
        >
          <div className="app-confirm-dialog" role="alertdialog" aria-modal="true">
            <h3>{confirmDialog.title}</h3>
            <p>{confirmDialog.message}</p>
            <div className="app-confirm-actions">
              <button
                type="button"
                className="button button--ghost"
                onClick={() => closeConfirmDialog(false)}
              >
                {confirmDialog.cancelLabel}
              </button>
              <button
                type="button"
                className={`button ${confirmDialog.tone === 'danger' ? 'button--danger' : ''}`}
                onClick={() => closeConfirmDialog(true)}
              >
                {confirmDialog.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {showLoadingOverlay ? (
        <div className="app-loading-overlay" role="status" aria-live="polite">
          <div className="app-loading-dialog">
            <div className="app-loading-spinner" aria-hidden="true" />
            <p>Menyimpan perubahan...</p>
          </div>
        </div>
      ) : null}
    </div>
  )
}

export default PetugasSection

