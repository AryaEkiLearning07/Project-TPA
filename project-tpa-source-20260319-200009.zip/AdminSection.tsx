import {
  Menu,
  CheckCircle2,
  Eye,
  EyeOff,
} from 'lucide-react'
import { type ChangeEvent, type FormEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import SearchableSelect from '../../components/common/SearchableSelect'
import Sidebar from '../../components/layout/Sidebar'
import {
  adminApi,
  attendanceApi,
  childApi,
  incidentApi,
  observationApi,
} from '../../services/api'
import DataAnakPage from '../petugas/data-anak/DataAnakPage'
import { downloadBeritaAcaraPdf } from '../petugas/berita-acara/beritaAcaraPdf'
import { downloadObservationBatchPdf } from './observationPdf'
import { downloadStaffAttendancePdf } from './staffAttendancePdf'
import { downloadRekapAttendancePdf } from './rekap-bulanan/rekapPdf'
import type {
  ActivityLogEntry,
  AppData,
  AuthUser,
  ChildProfile,
  ChildProfileInput,
  ConfirmDialogOptions,
  ServiceBillingSummaryResponse,
  ServiceBillingHistoryResponse,
  ServiceBillingPeriodInput,
  ServiceBillingPaymentInput,
  ServiceBillingRefundInput,
  ServicePackage,
  ServicePackageRates,
  StaffAttendanceRecapRow,
  StaffUser,
  StaffUserInput,
} from '../../types'
import { getLocalDateIso } from '../../utils/date'
import { compressImageToDataUrl } from '../../utils/image'
import { createEmptyAppData } from '../../utils/storage'
import {
  parseNavigationState,
  pushNavigationState,
  readNavigationState,
  replaceNavigationState,
} from '../../utils/browser-history'
import { useHideOnScroll } from '../../utils/useHideOnScroll'
import {
  type AdminSidebarKey,
  type MonitoringSubTab,
  type SettingsSubTab,
  type ConfirmDialogState,
  type StaffAttendanceSummary,
  type ServiceMonthlyRecapRow,
  type ServiceMonthChildRow,
  type ServiceMonthlyDetail,

  type ServiceBillingArrearsRow,
  type ObservationRecapRow,
  type DownloadNoticeType,
  type ServiceGenderKey,
  isAdminNavigationState,
  buildAdminNavigationState,
  adminMenus,
  monitoringSubTabs,
  settingsSubTabs,
  sidebarTitles,
  initialStaffForm,
  initialServiceRates,
  initialServiceBillingPeriodForm,
  initialServiceBillingPaymentForm,
  initialServiceBillingRefundForm,
  ACTIVITY_LOG_LIMIT_OPTIONS,
  DEFAULT_ACTIVITY_LOG_LIMIT,
  formatLogDateTimeParts,
  formatDateOnly,
  formatDateWithWeekday,
  formatMonthLabel,
  formatTimeOnly,
  calculateServiceLength,
  calculateIsSenior,
  calculateStaffPay,
  formatRupiah,
  formatCurrency,
  formatRupiahInput,
  parseRupiahInput,
  toUnpaidAttendanceDays,
  downloadBlob,
  toLocalDateKey,
  calculateDutyMinutes,
  formatDutyDuration,
  clampDateKeyToToday,
  clampMonthKeyToToday,
  servicePackageLabels,
  createServicePackageCounter,
  servicePackageTableOrder,
  resolveServiceGenderKey,
  createEmptyObservationCategorySummary,
  summarizeObservationItems,
  defaultObservationGroupOptions,
  resolveObservationGroupFilterValue,
} from './adminHelpers'
import { servicePackageOptions } from '../../constants/options'

interface AdminSectionProps {
  user: AuthUser
  onLogout: () => Promise<void>
}

type IncidentPdfMode = 'date' | 'month'
type StaffAttendancePdfMode = 'daily' | 'monthly' | 'yearly'

const clampOptionalDateKeyToToday = (value: string): string => {
  const normalized = value.trim()
  if (!normalized) {
    return ''
  }
  return clampDateKeyToToday(normalized)
}

const getMonthDateBounds = (monthKey: string, todayDate: string): { min: string; max: string } => {
  if (!/^\d{4}-\d{2}$/.test(monthKey)) {
    return {
      min: todayDate.slice(0, 7) + '-01',
      max: todayDate,
    }
  }

  const [yearText, monthText] = monthKey.split('-')
  const year = Number(yearText)
  const month = Number(monthText)
  const daysInMonth = new Date(year, month, 0).getDate()
  const monthEndDate = `${monthKey}-${String(daysInMonth).padStart(2, '0')}`

  return {
    min: `${monthKey}-01`,
    max: monthEndDate > todayDate ? todayDate : monthEndDate,
  }
}

const AdminSection = ({ user, onLogout }: AdminSectionProps) => {
  const [activeSidebar, setActiveSidebar] = useState<AdminSidebarKey>('monitoring')
  const [monitoringTab, setMonitoringTab] = useState<MonitoringSubTab>('kehadiran-anak')
  const [settingsTab, setSettingsTab] = useState<SettingsSubTab>('petugas')
  const [isSidebarOpen, setSidebarOpen] = useState(false)
  const [staffUsers, setStaffUsers] = useState<StaffUser[]>([])
  const [activityLogs, setActivityLogs] = useState<ActivityLogEntry[]>([])
  const [staffAttendanceRecapRows, setStaffAttendanceRecapRows] = useState<
    StaffAttendanceRecapRow[]
  >([])
  const [appData, setAppData] = useState<AppData>(() => createEmptyAppData())
  const [serviceRates, setServiceRates] = useState<ServicePackageRates>(initialServiceRates)
  const [serviceBillingSummary, setServiceBillingSummary] = useState<ServiceBillingSummaryResponse | null>(null)
  const [serviceBillingHistory, setServiceBillingHistory] = useState<ServiceBillingHistoryResponse | null>(null)
  const [selectedBillingChildId, setSelectedBillingChildId] = useState('')
  const [serviceBillingPeriodForm, setServiceBillingPeriodForm] = useState<ServiceBillingPeriodInput>(
    initialServiceBillingPeriodForm,
  )
  const [serviceBillingPaymentForm, setServiceBillingPaymentForm] = useState<ServiceBillingPaymentInput>(
    initialServiceBillingPaymentForm,
  )
  const [serviceBillingRefundForm, setServiceBillingRefundForm] = useState<ServiceBillingRefundInput>(
    initialServiceBillingRefundForm,
  )
  const [staffForm, setStaffForm] = useState<StaffUserInput>(initialStaffForm)
  const [editingStaffId, setEditingStaffId] = useState<string | null>(null)
  const [showStaffPassword, setShowStaffPassword] = useState(false)
  const [searchLogs, setSearchLogs] = useState('')
  const [activityLogLimit, setActivityLogLimit] = useState(DEFAULT_ACTIVITY_LOG_LIMIT)
  const [activityLogPage, setActivityLogPage] = useState(1)
  const [activityLogPageCursor, setActivityLogPageCursor] = useState<string | null>(null)
  const [activityLogNextCursor, setActivityLogNextCursor] = useState<string | null>(null)
  const [activityLogHasMore, setActivityLogHasMore] = useState(false)
  const [observationFilterGroup, setObservationFilterGroup] = useState('')
  const [observationFilterMonth, setObservationFilterMonth] = useState(
    () => getLocalDateIso().slice(0, 7),
  )
  const [observationFilterDate, setObservationFilterDate] = useState('')
  const [incidentFilterMonth, setIncidentFilterMonth] = useState(
    () => getLocalDateIso().slice(0, 7),
  )
  const [incidentFilterDate, setIncidentFilterDate] = useState('')
  const [incidentFilterChild, setIncidentFilterChild] = useState('')
  const [staffAttendanceFilterDate, setStaffAttendanceFilterDate] = useState(
    () => getLocalDateIso(),
  )
  const [staffAttendanceFilterMonth, setStaffAttendanceFilterMonth] = useState(
    () => getLocalDateIso().slice(0, 7),
  )
  const [serviceRecapYear, setServiceRecapYear] = useState(() =>
    getLocalDateIso().slice(0, 4),
  )
  const [serviceRecapMonth, setServiceRecapMonth] = useState(() =>
    getLocalDateIso().slice(0, 7),
  )
  const [isServiceBillingSettlementOpen, setServiceBillingSettlementOpen] = useState(true)
  const [serviceBillingPaidMonth, setServiceBillingPaidMonth] = useState(() => getLocalDateIso().slice(0, 7))
  const [serviceBillingPaidPackage, setServiceBillingPaidPackage] = useState<ServicePackage | ''>('')
  const [serviceBillingPaidLimit, setServiceBillingPaidLimit] = useState<number>(20)
  const [servicePaymentAmountText, setServicePaymentAmountText] = useState(
    formatRupiahInput(initialServiceBillingPaymentForm.amount),
  )
  const [isLoadingStaff, setLoadingStaff] = useState(false)
  const [isLoadingLogs, setLoadingLogs] = useState(false)
  const [isLoadingServices, setLoadingServices] = useState(false)
  const [isLoadingServiceBilling, setLoadingServiceBilling] = useState(false)
  const [isLoadingStaffAttendance, setLoadingStaffAttendance] = useState(false)
  const [isMutatingServiceBilling, setMutatingServiceBilling] = useState(false)
  const [isProcessingBackup, setProcessingBackup] = useState(false)
  const [isDownloadingObservationPdf, setDownloadingObservationPdf] = useState(false)
  const [downloadingObservationChildId, setDownloadingObservationChildId] = useState<string | null>(null)
  const [isDownloadingIncidentPdf, setDownloadingIncidentPdf] = useState(false)
  const [isIncidentPdfDialogOpen, setIncidentPdfDialogOpen] = useState(false)
  const [incidentPdfMode, setIncidentPdfMode] = useState<IncidentPdfMode>('month')
  const [incidentPdfFilterMonth, setIncidentPdfFilterMonth] = useState(() => getLocalDateIso().slice(0, 7))
  const [incidentPdfFilterDate, setIncidentPdfFilterDate] = useState('')

  const [isDownloadingStaffAttendancePdf, setDownloadingStaffAttendancePdf] = useState(false)
  const [isStaffAttendancePdfDialogOpen, setStaffAttendancePdfDialogOpen] = useState(false)
  const [staffAttendancePdfMode, setStaffAttendancePdfMode] = useState<StaffAttendancePdfMode>('daily')
  const [staffAttendancePdfYear, setStaffAttendancePdfYear] = useState(() => getLocalDateIso().slice(0, 4))
  const [isDownloadingKehadiranAnakPdf, setDownloadingKehadiranAnakPdf] = useState(false)
  const [kehadiranAnakPdfNotice, setKehadiranAnakPdfNotice] = useState<{ type: DownloadNoticeType; text: string } | null>(null)
  const [kehadiranAnakPage, setKehadiranAnakPage] = useState(1)
  const KEHADIRAN_ANAK_PAGE_SIZE = 20

  const [observationFilterChild, setObservationFilterChild] = useState<string>('')
  const todayIso = useMemo(() => getLocalDateIso(), [])
  const [isSyncingAppData] = useState(false)
  const [observationPdfNotice, setObservationPdfNotice] = useState<{
    type: DownloadNoticeType
    text: string
  } | null>(null)
  const [incidentPdfNotice, setIncidentPdfNotice] = useState<{
    type: DownloadNoticeType
    text: string
  } | null>(null)
  const [staffAttendancePdfNotice, setStaffAttendancePdfNotice] = useState<{
    type: DownloadNoticeType
    text: string
  } | null>(null)
  const [message, setMessage] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [confirmDialog, setConfirmDialog] = useState<ConfirmDialogState | null>(null)
  const confirmResolveRef = useRef<((result: boolean) => void) | null>(null)
  const initialSidebarRef = useRef<AdminSidebarKey>(activeSidebar)
  const initialMonitoringTabRef = useRef<MonitoringSubTab>(monitoringTab)
  const initialSettingsTabRef = useRef<SettingsSubTab>(settingsTab)
  const isApplyingNavigationHistoryRef = useRef(false)
  const hasInitializedNavigationHistoryRef = useRef(false)
  const isTopbarHidden = useHideOnScroll()
  const hasLoadedChildrenRef = useRef(false)
  const hasLoadedAttendanceRef = useRef(false)
  const hasLoadedObservationRef = useRef(false)
  const hasLoadedIncidentRef = useRef(false)
  const hasLoadedServiceRatesRef = useRef(false)
  const childrenRequestRef = useRef<Promise<void> | null>(null)
  const attendanceRequestRef = useRef<Promise<void> | null>(null)
  const observationRequestRef = useRef<Promise<void> | null>(null)
  const incidentRequestRef = useRef<Promise<void> | null>(null)
  const serviceRatesRequestRef = useRef<Promise<void> | null>(null)

  const staffCountLabel = useMemo(() => `${staffUsers.length} petugas`, [staffUsers.length])
  const activeHeader = sidebarTitles[activeSidebar]

  // --- Confirm dialog ---
  const closeConfirmDialog = (result: boolean) => {
    const resolve = confirmResolveRef.current
    confirmResolveRef.current = null
    setConfirmDialog(null)
    if (resolve) {
      resolve(result)
    }
  }

  const requestConfirm = (options: ConfirmDialogOptions): Promise<boolean> =>
    new Promise((resolve) => {
      if (confirmResolveRef.current) {
        confirmResolveRef.current(false)
      }
      confirmResolveRef.current = resolve
      setConfirmDialog({
        title: options.title ?? 'Konfirmasi',
        message: options.message,
        confirmLabel: options.confirmLabel ?? 'Ya, Lanjutkan',
        cancelLabel: options.cancelLabel ?? 'Batal',
        tone: options.tone ?? 'default',
      })
    })

  useEffect(() => {
    if (!confirmDialog) {
      return undefined
    }

    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        closeConfirmDialog(false)
      }
    }

    document.addEventListener('keydown', handleEscapeKey)
    return () => {
      document.removeEventListener('keydown', handleEscapeKey)
    }
  }, [confirmDialog])

  useEffect(() => {
    if (!message) {
      return undefined
    }

    const timerId = window.setTimeout(() => {
      setMessage(null)
    }, 3000)

    return () => {
      window.clearTimeout(timerId)
    }
  }, [message])

  useEffect(
    () => () => {
      if (confirmResolveRef.current) {
        confirmResolveRef.current(false)
        confirmResolveRef.current = null
      }
    },
    [],
  )

  useEffect(() => {
    const restoredState = readNavigationState(isAdminNavigationState)

    if (restoredState) {
      const shouldRestore =
        restoredState.sidebar !== initialSidebarRef.current ||
        restoredState.monitoringTab !== initialMonitoringTabRef.current ||
        restoredState.settingsTab !== initialSettingsTabRef.current

      if (shouldRestore) {
        isApplyingNavigationHistoryRef.current = true
        setActiveSidebar(restoredState.sidebar)
        setMonitoringTab(restoredState.monitoringTab)
        setSettingsTab(restoredState.settingsTab)
      }
    } else {
      replaceNavigationState(
        buildAdminNavigationState(
          initialSidebarRef.current,
          initialMonitoringTabRef.current,
          initialSettingsTabRef.current,
        ),
      )
    }

    hasInitializedNavigationHistoryRef.current = true

    const handlePopState = (event: PopStateEvent) => {
      const nextState = parseNavigationState(event.state, isAdminNavigationState)
      if (!nextState) {
        return
      }

      isApplyingNavigationHistoryRef.current = true
      setActiveSidebar(nextState.sidebar)
      setMonitoringTab(nextState.monitoringTab)
      setSettingsTab(nextState.settingsTab)
      setSidebarOpen(false)
      setMessage(null)
      setErrorMessage(null)
    }

    window.addEventListener('popstate', handlePopState)
    return () => {
      window.removeEventListener('popstate', handlePopState)
    }
  }, [])

  useEffect(() => {
    if (!hasInitializedNavigationHistoryRef.current) {
      return
    }

    if (isApplyingNavigationHistoryRef.current) {
      isApplyingNavigationHistoryRef.current = false
      return
    }

    const currentState = readNavigationState(isAdminNavigationState)
    if (
      currentState?.sidebar === activeSidebar &&
      currentState?.monitoringTab === monitoringTab &&
      currentState?.settingsTab === settingsTab
    ) {
      return
    }

    pushNavigationState(
      buildAdminNavigationState(activeSidebar, monitoringTab, settingsTab),
    )
  }, [activeSidebar, monitoringTab, settingsTab])

  // --- Data loaders ---
  const loadStaff = async () => {
    setLoadingStaff(true)
    try {
      const data = await adminApi.getStaffUsers()
      setStaffUsers(data)
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Gagal memuat data petugas.'
      setErrorMessage(message)
    } finally {
      setLoadingStaff(false)
    }
  }

  const loadLogs = useCallback(async (
    query = '',
    options?: {
      silent?: boolean
      cursor?: string | null
      page?: number
      limit?: number
    },
  ) => {
    const isSilent = options?.silent === true
    const page = options?.page ?? 1
    const cursor = options?.cursor ?? null
    const limit = options?.limit ?? activityLogLimit
    if (!isSilent) {
      setLoadingLogs(true)
    }
    try {
      const data = await adminApi.getActivityLogs({
        search: query,
        limit,
        cursor,
      })
      setActivityLogs(data.entries)
      setActivityLogPage(page)
      setActivityLogPageCursor(cursor)
      setActivityLogNextCursor(data.nextCursor)
      setActivityLogHasMore(data.hasMore)
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Gagal memuat log aktivitas.'
      setErrorMessage(message)
    } finally {
      if (!isSilent) {
        setLoadingLogs(false)
      }
    }
  }, [activityLogLimit])

  const handleActivityLogLimitChange = (value: string) => {
    const parsed = Number.parseInt(value, 10)
    if (!ACTIVITY_LOG_LIMIT_OPTIONS.includes(parsed)) {
      return
    }

    setActivityLogLimit(parsed)
    void loadLogs(searchLogs, {
      limit: parsed,
      cursor: null,
      page: 1,
    })
  }

  const handleLoadNextLogs = () => {
    if (!activityLogHasMore || !activityLogNextCursor) {
      return
    }

    void loadLogs(searchLogs, {
      cursor: activityLogNextCursor,
      page: activityLogPage + 1,
    })
  }

  const loadStaffAttendanceRecap = useCallback(async (
    overrides?: {
      date?: string
      month?: string
    },
  ) => {
    const normalizedDate = clampDateKeyToToday(
      overrides?.date ?? staffAttendanceFilterDate,
    )
    const normalizedMonth = clampMonthKeyToToday(
      overrides?.month ?? staffAttendanceFilterMonth,
    )

    setLoadingStaffAttendance(true)
    try {
      const data = await adminApi.getStaffAttendanceRecap(
        normalizedDate,
        normalizedMonth,
      )
      setStaffAttendanceRecapRows(data)
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : 'Gagal memuat rekap kehadiran petugas.'
      setErrorMessage(message)
      setStaffAttendanceRecapRows([])
    } finally {
      setLoadingStaffAttendance(false)
    }
  }, [staffAttendanceFilterDate, staffAttendanceFilterMonth])

  const ensureChildrenData = useCallback(async (options?: { force?: boolean }) => {
    const forceReload = options?.force === true

    if (!forceReload && hasLoadedChildrenRef.current) {
      return
    }
    if (!forceReload && childrenRequestRef.current) {
      await childrenRequestRef.current
      return
    }

    const requestPromise = (async () => {
      const children = await childApi.getChildren()
      setAppData((previous) => ({
        ...previous,
        children,
      }))
      hasLoadedChildrenRef.current = true
    })()

    childrenRequestRef.current = requestPromise
    try {
      await requestPromise
    } finally {
      if (childrenRequestRef.current === requestPromise) {
        childrenRequestRef.current = null
      }
    }
  }, [])

  const ensureAttendanceData = useCallback(async (options?: { force?: boolean }) => {
    const forceReload = options?.force === true

    if (!forceReload && hasLoadedAttendanceRef.current) {
      return
    }
    if (!forceReload && attendanceRequestRef.current) {
      await attendanceRequestRef.current
      return
    }

    const requestPromise = (async () => {
      const attendanceRecords = await attendanceApi.getAttendanceRecords()
      setAppData((previous) => ({
        ...previous,
        attendanceRecords,
      }))
      hasLoadedAttendanceRef.current = true
    })()

    attendanceRequestRef.current = requestPromise
    try {
      await requestPromise
    } finally {
      if (attendanceRequestRef.current === requestPromise) {
        attendanceRequestRef.current = null
      }
    }
  }, [])

  const ensureObservationData = useCallback(async (options?: { force?: boolean }) => {
    const forceReload = options?.force === true

    if (!forceReload && hasLoadedObservationRef.current) {
      return
    }
    if (!forceReload && observationRequestRef.current) {
      await observationRequestRef.current
      return
    }

    const requestPromise = (async () => {
      const observationRecords = await observationApi.getObservationRecords()
      setAppData((previous) => ({
        ...previous,
        observationRecords,
      }))
      hasLoadedObservationRef.current = true
    })()

    observationRequestRef.current = requestPromise
    try {
      await requestPromise
    } finally {
      if (observationRequestRef.current === requestPromise) {
        observationRequestRef.current = null
      }
    }
  }, [])

  const ensureIncidentData = useCallback(async (options?: { force?: boolean }) => {
    const forceReload = options?.force === true

    if (!forceReload && hasLoadedIncidentRef.current) {
      return
    }
    if (!forceReload && incidentRequestRef.current) {
      await incidentRequestRef.current
      return
    }

    const requestPromise = (async () => {
      const incidentReports = await incidentApi.getIncidentReports()
      setAppData((previous) => ({
        ...previous,
        incidentReports,
      }))
      hasLoadedIncidentRef.current = true
    })()

    incidentRequestRef.current = requestPromise
    try {
      await requestPromise
    } finally {
      if (incidentRequestRef.current === requestPromise) {
        incidentRequestRef.current = null
      }
    }
  }, [])

  const ensureServiceRatesData = useCallback(async (options?: { force?: boolean }) => {
    const forceReload = options?.force === true

    if (!forceReload && hasLoadedServiceRatesRef.current) {
      return
    }
    if (!forceReload && serviceRatesRequestRef.current) {
      await serviceRatesRequestRef.current
      return
    }

    const requestPromise = (async () => {
      const nextRates = await adminApi.getServiceRates()
      setServiceRates(nextRates)
      hasLoadedServiceRatesRef.current = true
    })()

    serviceRatesRequestRef.current = requestPromise
    try {
      await requestPromise
    } finally {
      if (serviceRatesRequestRef.current === requestPromise) {
        serviceRatesRequestRef.current = null
      }
    }
  }, [])

  const loadMonitoringAttendanceData = useCallback(
    async (options?: { force?: boolean }) => {
      setLoadingServices(true)
      try {
        await Promise.all([
          ensureChildrenData(options),
          ensureAttendanceData(options),
        ])
      } catch (error) {
        const message =
          error instanceof Error ? error.message : 'Gagal memuat data kehadiran anak.'
        setErrorMessage(message)
      } finally {
        setLoadingServices(false)
      }
    },
    [ensureAttendanceData, ensureChildrenData],
  )

  const loadObservationMonitoringData = useCallback(
    async (options?: { force?: boolean }) => {
      setLoadingServices(true)
      try {
        await Promise.all([
          ensureChildrenData(options),
          ensureObservationData(options),
        ])
      } catch (error) {
        const message =
          error instanceof Error ? error.message : 'Gagal memuat data observasi anak.'
        setErrorMessage(message)
      } finally {
        setLoadingServices(false)
      }
    },
    [ensureChildrenData, ensureObservationData],
  )

  const loadIncidentMonitoringData = useCallback(
    async (options?: { force?: boolean }) => {
      setLoadingServices(true)
      try {
        await Promise.all([
          ensureChildrenData(options),
          ensureAttendanceData(options),
          ensureIncidentData(options),
        ])
      } catch (error) {
        const message =
          error instanceof Error ? error.message : 'Gagal memuat data berita acara.'
        setErrorMessage(message)
      } finally {
        setLoadingServices(false)
      }
    },
    [ensureAttendanceData, ensureChildrenData, ensureIncidentData],
  )

  const loadServiceManagement = useCallback(
    async (options?: { force?: boolean }) => {
      setLoadingServices(true)
      try {
        await Promise.all([
          ensureChildrenData(options),
          ensureAttendanceData(options),
          ensureServiceRatesData(options),
        ])
      } catch (error) {
        const message =
          error instanceof Error
            ? error.message
            : 'Gagal memuat data layanan anak dan tarif.'
        setErrorMessage(message)
      } finally {
        setLoadingServices(false)
      }
    },
    [ensureAttendanceData, ensureChildrenData, ensureServiceRatesData],
  )

  const loadServiceBillingSummary = useCallback(async (preferredChildId = '') => {
    setLoadingServiceBilling(true)
    try {
      const summary = await adminApi.getServiceBillingSummary()
      setServiceBillingSummary(summary)

      const availableChildIds = summary.rows.map((row) => row.childId)
      setSelectedBillingChildId((previous) => {
        const nextChildId =
          (preferredChildId && availableChildIds.includes(preferredChildId) && preferredChildId) ||
          (previous && availableChildIds.includes(previous) && previous) ||
          availableChildIds[0] ||
          ''
        const selectedSummary =
          summary.rows.find((row) => row.childId === nextChildId) ?? null
        const childChanged = previous !== nextChildId
        const suggestedPaymentAmount = Math.max(
          0,
          Math.round(selectedSummary?.totalOutstanding ?? 0),
        )

        setServiceBillingPeriodForm((previousPeriodForm) => ({
          ...previousPeriodForm,
          childId: nextChildId,
          packageKey:
            selectedSummary?.currentServicePackage ?? previousPeriodForm.packageKey,
        }))
        setServiceBillingPaymentForm((previousPaymentForm) => ({
          ...previousPaymentForm,
          childId: nextChildId,
          periodId: childChanged ? '' : previousPaymentForm.periodId,
          amount: childChanged ? suggestedPaymentAmount : previousPaymentForm.amount,
          paymentProofDataUrl: '',
          paymentProofName: '',
        }))
        setServiceBillingRefundForm((previousRefundForm) => ({
          ...previousRefundForm,
          childId: nextChildId,
          periodId: childChanged ? '' : previousRefundForm.periodId,
        }))
        if (childChanged) {
          setServicePaymentAmountText(formatRupiahInput(suggestedPaymentAmount))
        }

        return nextChildId
      })
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : 'Gagal memuat ringkasan pembayaran layanan.'
      setErrorMessage(message)
      setServiceBillingSummary(null)
      setSelectedBillingChildId('')
      setServiceBillingPeriodForm((previous) => ({
        ...previous,
        childId: '',
      }))
      setServiceBillingPaymentForm((previous) => ({
        ...previous,
        childId: '',
        amount: 0,
        periodId: '',
        paymentProofDataUrl: '',
        paymentProofName: '',
      }))
      setServicePaymentAmountText(formatRupiahInput(0))
      setServiceBillingRefundForm((previous) => ({
        ...previous,
        childId: '',
        periodId: '',
      }))
    } finally {
      setLoadingServiceBilling(false)
    }
  }, [])

  const loadServiceBillingHistory = useCallback(async (childId: string) => {
    if (!childId) {
      setServiceBillingHistory(null)
      return
    }

    setLoadingServiceBilling(true)
    try {
      const history = await adminApi.getServiceBillingHistory(childId)
      setServiceBillingHistory(history)
      const suggestedPaymentAmount = Math.max(
        0,
        Math.round(history.summary?.totalOutstanding ?? 0),
      )
      let shouldSyncPaymentText = false
      setServiceBillingPaymentForm((previous) => {
        const shouldAutoFillAmount =
          previous.childId !== childId || previous.amount <= 0
        shouldSyncPaymentText = shouldAutoFillAmount
        return {
          ...previous,
          periodId: previous.periodId || history.summary?.activePeriod?.id || '',
          amount: shouldAutoFillAmount
            ? suggestedPaymentAmount
            : previous.amount,
        }
      })
      if (shouldSyncPaymentText) {
        setServicePaymentAmountText(formatRupiahInput(suggestedPaymentAmount))
      }
      setServiceBillingRefundForm((previous) => ({
        ...previous,
        periodId: previous.periodId || history.summary?.activePeriod?.id || '',
      }))
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : 'Gagal memuat histori pembayaran layanan.'
      setErrorMessage(message)
      setServiceBillingHistory(null)
    } finally {
      setLoadingServiceBilling(false)
    }
  }, [])

  useEffect(() => {
    if (activeSidebar === 'settings') {
      if (settingsTab === 'petugas') {
        void loadStaff()
        return
      }

      if (settingsTab === 'logs') {
        void loadLogs()
      }
      return
    }

    if (activeSidebar === 'data-anak') {
      setLoadingServices(true)
      void ensureChildrenData()
        .catch((error) => {
          const message = error instanceof Error ? error.message : 'Gagal memuat data anak.'
          setErrorMessage(message)
        })
        .finally(() => {
          setLoadingServices(false)
        })
      return
    }

    if (monitoringTab === 'kehadiran-anak') {
      void loadMonitoringAttendanceData()
      return
    }

    if (monitoringTab === 'observasi-anak') {
      void loadObservationMonitoringData()
      return
    }

    if (monitoringTab === 'berita-acara') {
      void loadIncidentMonitoringData()
      return
    }

    if (monitoringTab === 'layanan') {
      void loadServiceManagement()
      void loadServiceBillingSummary()
    }
  }, [
    activeSidebar,
    monitoringTab,
    settingsTab,
    ensureChildrenData,
    loadIncidentMonitoringData,
    loadMonitoringAttendanceData,
    loadObservationMonitoringData,
    loadServiceBillingSummary,
    loadServiceManagement,
  ])

  useEffect(() => {
    if (activeSidebar !== 'settings' || settingsTab !== 'logs') {
      return
    }

    const intervalId = window.setInterval(() => {
      void loadLogs(searchLogs, {
        silent: true,
        cursor: activityLogPageCursor,
        page: activityLogPage,
      })
    }, 10000)

    return () => {
      window.clearInterval(intervalId)
    }
  }, [
    activeSidebar,
    settingsTab,
    searchLogs,
    loadLogs,
    activityLogPageCursor,
    activityLogPage,
  ])

  useEffect(() => {
    if (activeSidebar !== 'monitoring' || monitoringTab !== 'kehadiran-petugas') {
      return
    }

    void loadStaffAttendanceRecap()
  }, [
    activeSidebar,
    monitoringTab,
    loadStaffAttendanceRecap,
    staffAttendanceFilterDate,
    staffAttendanceFilterMonth,
  ])

  useEffect(() => {
    if (!selectedBillingChildId) {
      setServiceBillingHistory(null)
      return
    }
    void loadServiceBillingHistory(selectedBillingChildId)
  }, [loadServiceBillingHistory, selectedBillingChildId])

  const upsertChildProfileAdmin = async (
    input: ChildProfileInput,
    editingId?: string,
  ): Promise<boolean> => {
    setErrorMessage(null)
    setMessage(null)
    try {
      let saved: ChildProfile
      if (editingId) {
        saved = await childApi.updateChild(editingId, input)
      } else {
        saved = await childApi.createChild(input)
      }

      setAppData((previous) => ({
        ...previous,
        children: editingId
          ? previous.children.map((record) => (record.id === editingId ? saved : record))
          : [saved, ...previous.children],
      }))
      setMessage(editingId ? 'Data anak berhasil diperbarui.' : 'Data anak berhasil ditambahkan.')
      return true
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Gagal menyimpan data anak.'
      setErrorMessage(message)
      return false
    }
  }

  const removeChildProfileAdmin = async (id: string): Promise<boolean> => {
    setErrorMessage(null)
    setMessage(null)
    try {
      await childApi.deleteChild(id)
      setAppData((previous) => ({
        ...previous,
        children: previous.children.filter((record) => record.id !== id),
        incidentReports: previous.incidentReports.filter((record) => record.childId !== id),
        attendanceRecords: previous.attendanceRecords.filter((record) => record.childId !== id),
        observationRecords: previous.observationRecords.filter((record) => record.childId !== id),
        communicationBooks: previous.communicationBooks.filter((record) => record.childId !== id),
      }))
      setMessage('Data anak berhasil dihapus.')
      return true
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Gagal menghapus data anak.'
      setErrorMessage(message)
      return false
    }
  }


  // --- Staff CRUD ---
  const resetStaffForm = () => {
    setStaffForm(initialStaffForm)
    setEditingStaffId(null)
    setShowStaffPassword(false)
  }

  const validateStaffForm = (): string | null => {
    if (!staffForm.fullName.trim()) {
      return 'Nama petugas wajib diisi.'
    }
    if (!staffForm.email.trim()) {
      return 'Email petugas wajib diisi.'
    }
    if (!staffForm.tanggalMasuk) {
      return 'Tanggal masuk wajib diisi.'
    }
    if (!editingStaffId && staffForm.password.trim().length < 8) {
      return 'Password petugas minimal 8 karakter.'
    }
    if (
      editingStaffId &&
      staffForm.password.trim().length > 0 &&
      staffForm.password.trim().length < 8
    ) {
      return 'Password baru minimal 8 karakter.'
    }
    return null
  }

  const handleSubmitStaff = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setErrorMessage(null)
    setMessage(null)

    const validationError = validateStaffForm()
    if (validationError) {
      setErrorMessage(validationError)
      return
    }

    try {
      if (editingStaffId) {
        await adminApi.updateStaffUser(editingStaffId, {
          fullName: staffForm.fullName.trim(),
          email: staffForm.email.trim().toLowerCase(),
          password: staffForm.password,
          isActive: staffForm.isActive,
          tanggalMasuk: staffForm.tanggalMasuk,
        })
        setMessage('Akun petugas berhasil diperbarui.')
      } else {
        await adminApi.createStaffUser({
          fullName: staffForm.fullName.trim(),
          email: staffForm.email.trim().toLowerCase(),
          password: staffForm.password,
          isActive: staffForm.isActive,
          tanggalMasuk: staffForm.tanggalMasuk,
        })
        setMessage('Akun petugas berhasil dibuat.')
      }
      resetStaffForm()
      await Promise.all([loadStaff(), loadLogs(searchLogs), loadStaffAttendanceRecap()])
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Gagal menyimpan data petugas.'
      setErrorMessage(message)
    }
  }

  const handleDeleteStaff = async (staff: StaffUser) => {
    setErrorMessage(null)
    setMessage(null)

    const confirmed = await requestConfirm({
      title: 'Hapus Akun Petugas',
      message: (
        <div className="confirm-delete-warning">
          <p>Apakah Anda yakin ingin menghapus akun petugas <strong>"{staff.fullName}"</strong>?</p>
          <div className="alert alert--danger" style={{ marginTop: '1rem' }}>
            <strong>PENTING:</strong> Menghapus akun petugas akan <strong>menghapus permanen</strong> seluruh riwayat kehadiran petugas tersebut dari sistem.
            <br /><br />
            Jika petugas hanya berhenti bekerja, kami sangat menyarankan untuk menonaktifkan akun saja (Ubah status ke <strong>Nonaktif</strong>) agar data riwayat tetap tersimpan.
          </div>
        </div>
      ),
      confirmLabel: 'Ya, Hapus Permanen',
      cancelLabel: 'Batal',
      tone: 'danger',
    })
    if (!confirmed) {
      return
    }

    try {
      await adminApi.deleteStaffUser(staff.id)
      setMessage('Akun petugas berhasil dihapus.')
      if (editingStaffId === staff.id) {
        resetStaffForm()
      }
      await Promise.all([loadStaff(), loadLogs(searchLogs), loadStaffAttendanceRecap()])
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Gagal menghapus akun petugas.'
      setErrorMessage(message)
    }
  }

  const startEditStaff = (staff: StaffUser) => {
    setEditingStaffId(staff.id)
    setStaffForm({
      fullName: staff.fullName,
      email: staff.email,
      password: '',
      isActive: staff.isActive,
      tanggalMasuk: staff.createdAt,
    })
    setShowStaffPassword(false)
    setActiveSidebar('settings')
    setSettingsTab('petugas')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleCreateBillingPeriod = async () => {
    setErrorMessage(null)
    setMessage(null)

    if (!serviceBillingPeriodForm.childId) {
      setErrorMessage('Pilih anak terlebih dahulu untuk mulai periode billing.')
      return
    }

    setMutatingServiceBilling(true)
    try {
      const payload: ServiceBillingPeriodInput = {
        childId: serviceBillingPeriodForm.childId,
        packageKey: serviceBillingPeriodForm.packageKey,
        startDate: serviceBillingPeriodForm.startDate || undefined,
        amount: Math.max(0, Math.round(serviceBillingPeriodForm.amount ?? 0)),
        notes: serviceBillingPeriodForm.notes?.trim() || '',
      }
      const history = await adminApi.createServiceBillingPeriod(payload)
      setServiceBillingHistory(history)
      await loadServiceBillingSummary(payload.childId)
      setMessage('Periode billing berhasil dibuat.')
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : 'Gagal membuat periode billing.'
      setErrorMessage(message)
    } finally {
      setMutatingServiceBilling(false)
    }
  }

  const handleCreateBillingPayment = async () => {
    setErrorMessage(null)
    setMessage(null)

    if (!serviceBillingPaymentForm.childId) {
      setErrorMessage('Pilih anak terlebih dahulu untuk mencatat pembayaran.')
      return
    }

    setMutatingServiceBilling(true)
    try {
      const payload: ServiceBillingPaymentInput = {
        childId: serviceBillingPaymentForm.childId,
        amount: Math.max(0, Math.round(serviceBillingPaymentForm.amount)),
        bucket: serviceBillingPaymentForm.bucket,
        periodId:
          serviceBillingPaymentForm.bucket === 'period'
            ? serviceBillingPaymentForm.periodId || serviceBillingHistory?.summary?.activePeriod?.id
            : undefined,
        notes: serviceBillingPaymentForm.notes?.trim() || '',
        paymentProofDataUrl: serviceBillingPaymentForm.paymentProofDataUrl || undefined,
        paymentProofName: serviceBillingPaymentForm.paymentProofName || undefined,
      }
      const history = await adminApi.createServiceBillingPayment(payload)
      setServiceBillingHistory(history)
      await loadServiceBillingSummary(payload.childId)
      setMessage('Pembayaran billing berhasil dicatat.')
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : 'Gagal mencatat pembayaran billing.'
      setErrorMessage(message)
    } finally {
      setMutatingServiceBilling(false)
    }
  }

  const handleServicePaymentAmountInput = (value: string) => {
    const amount = parseRupiahInput(value)
    setServicePaymentAmountText(formatRupiahInput(amount))
    setServiceBillingPaymentForm((previous) => ({
      ...previous,
      amount,
    }))
  }

  const handleServicePaymentAmountBlur = () => {
    setServicePaymentAmountText(
      formatRupiahInput(serviceBillingPaymentForm.amount),
    )
  }

  const handleServicePaymentProofChange = async (
    event: ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0]
    if (!file) {
      return
    }

    try {
      const result = await compressImageToDataUrl(file, {
        maxDimension: 1280,
        quality: 0.75,
      })
      setServiceBillingPaymentForm((previous) => ({
        ...previous,
        paymentProofDataUrl: result.dataUrl,
        paymentProofName: result.name,
      }))
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : 'Gagal memproses bukti pembayaran.'
      setErrorMessage(message)
    } finally {
      event.target.value = ''
    }
  }

  const clearServicePaymentProof = () => {
    setServiceBillingPaymentForm((previous) => ({
      ...previous,
      paymentProofDataUrl: '',
      paymentProofName: '',
    }))
  }

  const handleSelectServiceBillingArrearsChild = useCallback((childId: string) => {
    setErrorMessage(null)
    setMessage(null)

    const selectedRow =
      serviceBillingSummary?.rows.find((rowId: any) => rowId.childId === childId) ?? null
    const suggestedPaymentAmount = Math.max(
      0,
      Math.round(selectedRow?.totalOutstanding ?? 0),
    )

    setSelectedBillingChildId(childId)
    setServiceBillingPeriodForm((previous) => ({
      ...previous,
      childId,
      packageKey: selectedRow?.currentServicePackage ?? previous.packageKey,
    }))
    setServiceBillingPaymentForm((previous) => ({
      ...previous,
      childId,
      periodId: selectedRow?.activePeriod?.id || '',
      amount: suggestedPaymentAmount,
      notes: previous.childId === childId ? previous.notes : '',
      paymentProofDataUrl: previous.childId === childId ? previous.paymentProofDataUrl : '',
      paymentProofName: previous.childId === childId ? previous.paymentProofName : '',
    }))
    setServiceBillingRefundForm((previous) => ({
      ...previous,
      childId,
      periodId: selectedRow?.activePeriod?.id || '',
    }))
    setServicePaymentAmountText(formatRupiahInput(suggestedPaymentAmount))
  }, [serviceBillingSummary?.rows])

  const handleQuickServicePayment = async () => {
    setErrorMessage(null)
    setMessage(null)

    const childId = serviceBillingPaymentForm.childId
    if (!childId) {
      setErrorMessage('Pilih anak terlebih dahulu.')
      return
    }

    const summary = selectedServiceBillingSummary
    if (!summary) {
      setErrorMessage('Ringkasan billing anak belum tersedia.')
      return
    }

    const amount = Math.max(0, Math.round(serviceBillingPaymentForm.amount))
    if (amount <= 0) {
      setErrorMessage('Nominal pembayaran harus lebih dari 0.')
      return
    }

    const activePeriodId =
      summary.activePeriod?.id || serviceBillingHistory?.summary?.activePeriod?.id || ''

    setMutatingServiceBilling(true)
    try {
      let remaining = amount
      let latestHistory: ServiceBillingHistoryResponse | null = null

      if (summary.outstandingPeriod > 0 && remaining > 0) {
        if (!activePeriodId) {
          throw new Error('Periode aktif tidak ditemukan untuk pembayaran periode.')
        }
        const paymentAmount = Math.min(
          remaining,
          Math.max(0, Math.round(summary.outstandingPeriod)),
        )
        if (paymentAmount > 0) {
          latestHistory = await adminApi.createServiceBillingPayment({
            childId,
            amount: paymentAmount,
            bucket: 'period',
            periodId: activePeriodId,
            notes: serviceBillingPaymentForm.notes?.trim() || 'Pembayaran tunggakan layanan',
            paymentProofDataUrl:
              serviceBillingPaymentForm.paymentProofDataUrl || undefined,
            paymentProofName: serviceBillingPaymentForm.paymentProofName || undefined,
          })
          remaining -= paymentAmount
        }
      }

      if (summary.outstandingArrears > 0 && remaining > 0) {
        const arrearsPaymentAmount = Math.min(
          remaining,
          Math.max(0, Math.round(summary.outstandingArrears)),
        )
        if (arrearsPaymentAmount > 0) {
          latestHistory = await adminApi.createServiceBillingPayment({
            childId,
            amount: arrearsPaymentAmount,
            bucket: 'arrears',
            notes:
              serviceBillingPaymentForm.notes?.trim() ||
              'Pembayaran tunggakan harian layanan',
            paymentProofDataUrl:
              serviceBillingPaymentForm.paymentProofDataUrl || undefined,
            paymentProofName: serviceBillingPaymentForm.paymentProofName || undefined,
          })
          remaining -= arrearsPaymentAmount
        }
      }

      if (remaining > 0) {
        const fallbackBucket =
          summary.outstandingPeriod > 0 ? 'period' : 'arrears'
        latestHistory = await adminApi.createServiceBillingPayment({
          childId,
          amount: remaining,
          bucket: fallbackBucket,
          periodId: fallbackBucket === 'period' ? activePeriodId || undefined : undefined,
          notes: serviceBillingPaymentForm.notes?.trim() || 'Pembayaran layanan',
          paymentProofDataUrl:
            serviceBillingPaymentForm.paymentProofDataUrl || undefined,
          paymentProofName: serviceBillingPaymentForm.paymentProofName || undefined,
        })
      }

      if (latestHistory) {
        setServiceBillingHistory(latestHistory)
      }
      await loadServiceBillingSummary(childId)
      await loadServiceBillingHistory(childId)
      setMessage('Pembayaran layanan berhasil dicatat.')
      setServiceBillingPaymentForm((previous) => ({
        ...previous,
        amount: 0,
        notes: '',
        paymentProofDataUrl: '',
        paymentProofName: '',
      }))
      setServicePaymentAmountText(formatRupiahInput(0))
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : 'Gagal mencatat pembayaran layanan.'
      setErrorMessage(message)
    } finally {
      setMutatingServiceBilling(false)
    }
  }

  const handleCreateBillingRefund = async () => {
    setErrorMessage(null)
    setMessage(null)

    if (!serviceBillingRefundForm.childId) {
      setErrorMessage('Pilih anak terlebih dahulu untuk mencatat refund.')
      return
    }

    setMutatingServiceBilling(true)
    try {
      const payload: ServiceBillingRefundInput = {
        childId: serviceBillingRefundForm.childId,
        amount: Math.max(0, Math.round(serviceBillingRefundForm.amount)),
        bucket: serviceBillingRefundForm.bucket,
        periodId:
          serviceBillingRefundForm.bucket === 'period'
            ? serviceBillingRefundForm.periodId || serviceBillingHistory?.summary?.activePeriod?.id
            : undefined,
        notes: serviceBillingRefundForm.notes?.trim() || '',
      }
      const history = await adminApi.createServiceBillingRefund(payload)
      setServiceBillingHistory(history)
      await loadServiceBillingSummary(payload.childId)
      setMessage('Refund billing berhasil dicatat.')
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : 'Gagal mencatat refund billing.'
      setErrorMessage(message)
    } finally {
      setMutatingServiceBilling(false)
    }
  }

  // --- Backup ---
  const handleBackup = async () => {
    setProcessingBackup(true)
    setErrorMessage(null)
    setMessage(null)

    try {
      const { blob, fileName } = await adminApi.downloadBackup()
      const safeFileName = fileName || `backup-tpa-${Date.now()}.json`
      downloadBlob(blob, safeFileName)
      setMessage(`Backup berhasil diunduh (${safeFileName}).`)
      await loadLogs(searchLogs)
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Gagal melakukan backup.'
      setErrorMessage(message)
    } finally {
      setProcessingBackup(false)
    }
  }

  // --- Navigation ---
  const selectMenu = (menu: string) => {
    setActiveSidebar(menu as AdminSidebarKey)
    setSidebarOpen(false)
    setMessage(null)
    setErrorMessage(null)
  }

  const handleObservationGroupFilterChange = (value: string) => {
    setObservationFilterGroup(value)
    setObservationPdfNotice(null)
  }

  const handleObservationMonthFilterChange = (value: string) => {
    const normalizedMonth = clampMonthKeyToToday(value)
    setObservationFilterMonth(normalizedMonth)

    if (observationFilterDate && !observationFilterDate.startsWith(normalizedMonth)) {
      setObservationFilterDate('')
    }
    setObservationPdfNotice(null)
  }

  const handleObservationDateFilterChange = (value: string) => {
    const normalizedDate = clampOptionalDateKeyToToday(value)
    setObservationFilterDate(normalizedDate)
    if (normalizedDate) {
      setObservationFilterMonth(clampMonthKeyToToday(normalizedDate.slice(0, 7)))
    }
    setObservationPdfNotice(null)
  }

  const handleIncidentMonthFilterChange = (value: string) => {
    const normalizedMonth = clampMonthKeyToToday(value)
    setIncidentFilterMonth(normalizedMonth)

    if (incidentFilterDate && !incidentFilterDate.startsWith(normalizedMonth)) {
      setIncidentFilterDate('')
    }
    setIncidentPdfNotice(null)
  }

  const handleIncidentDateFilterChange = (value: string) => {
    const normalizedDate = clampOptionalDateKeyToToday(value)
    setIncidentFilterDate(normalizedDate)
    if (normalizedDate) {
      setIncidentFilterMonth(clampMonthKeyToToday(normalizedDate.slice(0, 7)))
    }
    setIncidentPdfNotice(null)
  }

  const openIncidentPdfDialog = () => {
    setIncidentPdfMode(incidentFilterDate ? 'date' : 'month')
    setIncidentPdfFilterMonth(incidentFilterMonth)
    setIncidentPdfFilterDate(incidentFilterDate)
    setIncidentPdfDialogOpen(true)
  }

  const openStaffAttendancePdfDialog = () => {
    setStaffAttendancePdfMode('daily')
    setStaffAttendancePdfYear(staffAttendanceFilterMonth.slice(0, 4))
    setStaffAttendancePdfDialogOpen(true)
    setStaffAttendancePdfNotice(null)
  }

  const handleStaffAttendanceDateFilterChange = (value: string) => {
    const normalizedDate = clampDateKeyToToday(value)
    setStaffAttendanceFilterDate(normalizedDate)

    if (normalizedDate.length >= 7) {
      setStaffAttendanceFilterMonth(clampMonthKeyToToday(normalizedDate.slice(0, 7)))
    }
    setStaffAttendancePdfNotice(null)
  }

  const handleStaffAttendanceMonthFilterChange = (value: string) => {
    const normalizedMonth = clampMonthKeyToToday(value)
    setStaffAttendanceFilterMonth(normalizedMonth)
    if (!staffAttendanceFilterDate.startsWith(normalizedMonth)) {
      setStaffAttendanceFilterDate(`${normalizedMonth}-01`)
    }
    setStaffAttendancePdfNotice(null)
  }

  useEffect(() => {
    const clampedObservationMonth = clampMonthKeyToToday(observationFilterMonth)
    if (clampedObservationMonth !== observationFilterMonth) {
      setObservationFilterMonth(clampedObservationMonth)
    }
    if (observationFilterDate && !observationFilterDate.startsWith(clampedObservationMonth)) {
      setObservationFilterDate('')
    }

    const clampedIncidentMonth = clampMonthKeyToToday(incidentFilterMonth)
    if (clampedIncidentMonth !== incidentFilterMonth) {
      setIncidentFilterMonth(clampedIncidentMonth)
    }
    if (incidentFilterDate && !incidentFilterDate.startsWith(clampedIncidentMonth)) {
      setIncidentFilterDate('')
    }

    const clampedDate = clampDateKeyToToday(staffAttendanceFilterDate)
    if (clampedDate !== staffAttendanceFilterDate) {
      setStaffAttendanceFilterDate(clampedDate)
    }

    const clampedMonth = clampMonthKeyToToday(staffAttendanceFilterMonth)
    if (clampedMonth !== staffAttendanceFilterMonth) {
      setStaffAttendanceFilterMonth(clampedMonth)
    }
  }, [
    incidentFilterDate,
    incidentFilterMonth,
    observationFilterDate,
    observationFilterMonth,
    staffAttendanceFilterDate,
    staffAttendanceFilterMonth,
  ])

  const childNameById = useMemo(
    () =>
      appData.children.reduce<Record<string, string>>((accumulator, child) => {
        accumulator[child.id] = child.fullName
        return accumulator
      }, {}),
    [appData.children],
  )

  const observationGroupOptions = useMemo(() => {
    const map = new Map<string, string>()
    for (const option of defaultObservationGroupOptions) {
      map.set(option.value, option.label)
    }

    for (const record of appData.observationRecords) {
      const label = record.groupName.trim()
      if (!label) continue
      const key = resolveObservationGroupFilterValue(label)
      if (!map.has(key)) {
        map.set(key, label)
      }
    }

    return Array.from(map.entries())
      .map(([value, label]) => ({ value, label }))
      .sort((left, right) => left.label.localeCompare(right.label, 'id-ID'))
  }, [appData.observationRecords])

  const selectedObservationGroupLabel =
    observationGroupOptions.find((option) => option.value === observationFilterGroup)?.label ?? ''

  const observationDateBounds = useMemo(
    () => getMonthDateBounds(observationFilterMonth, todayIso),
    [observationFilterMonth, todayIso],
  )

  const observationScopedRecords = useMemo(
    () =>
      appData.observationRecords.filter((record) => {
        if (
          observationFilterGroup &&
          resolveObservationGroupFilterValue(record.groupName) !== observationFilterGroup
        ) {
          return false
        }
        if (observationFilterChild && record.childId !== observationFilterChild) {
          return false
        }
        if (observationFilterDate) {
          return record.date === observationFilterDate
        }
        return record.date.startsWith(observationFilterMonth)
      }),
    [
      appData.observationRecords,
      observationFilterChild,
      observationFilterDate,
      observationFilterGroup,
      observationFilterMonth,
    ],
  )

  const observationMonthlyRecords = useMemo(
    () =>
      appData.observationRecords.filter((record) => {
        if (
          observationFilterGroup &&
          resolveObservationGroupFilterValue(record.groupName) !== observationFilterGroup
        ) {
          return false
        }
        if (observationFilterChild && record.childId !== observationFilterChild) {
          return false
        }
        return record.date.startsWith(observationFilterMonth)
      }),
    [
      appData.observationRecords,
      observationFilterChild,
      observationFilterGroup,
      observationFilterMonth,
    ],
  )

  const observationRecapRows = useMemo<ObservationRecapRow[]>(() => {
    const map = new Map<
      string,
      ObservationRecapRow & {
        latestSortKey: string
      }
    >()

    for (const record of observationScopedRecords) {
      const current =
        map.get(record.childId) ??
        {
          childId: record.childId,
          childName: childNameById[record.childId] ?? 'Data anak dihapus',
          latestDate: '',
          latestGroup: '-',
          totalObservations: 0,
          totalPoints: 0,
          categorySummary: createEmptyObservationCategorySummary(),
          latestSortKey: '',
        }

      current.totalObservations += 1
      current.totalPoints += record.items.length

      const recordSummary = summarizeObservationItems(record.items)
      current.categorySummary.perluArahan += recordSummary.perluArahan
      current.categorySummary.perluLatihan += recordSummary.perluLatihan
      current.categorySummary.sudahBaik += recordSummary.sudahBaik

      const currentSortKey = `${record.date}-${record.updatedAt || record.createdAt}`
      if (currentSortKey >= current.latestSortKey) {
        current.latestSortKey = currentSortKey
        current.latestDate = record.date
        current.latestGroup = record.groupName || '-'
      }

      map.set(record.childId, current)
    }

    return Array.from(map.values()).map(({ latestSortKey, ...row }) => {
      void latestSortKey
      return row
    })
  }, [childNameById, observationScopedRecords])

  const sortedObservationRecapRows = useMemo(
    () =>
      [...observationRecapRows].sort((left, right) => {
        const dateCompare = right.latestDate.localeCompare(left.latestDate)
        if (dateCompare !== 0) {
          return dateCompare
        }
        return left.childName.localeCompare(right.childName, 'id-ID')
      }),
    [observationRecapRows],
  )

  const observationChildIdsWithMonthlyRecords = useMemo(
    () => new Set(observationMonthlyRecords.map((record) => record.childId)),
    [observationMonthlyRecords],
  )

  const canDownloadObservationAll = Boolean(observationFilterGroup && observationFilterChild)

  const resolveObservationMonthlyRecordsByChild = useCallback(
    (childId: string) =>
      observationMonthlyRecords
        .filter((record) => record.childId === childId)
        .sort((left, right) => {
          const dateCompare = left.date.localeCompare(right.date)
          if (dateCompare !== 0) {
            return dateCompare
          }
          return (left.createdAt || '').localeCompare(right.createdAt || '')
        }),
    [observationMonthlyRecords],
  )

  const incidentDateBounds = useMemo(
    () => getMonthDateBounds(incidentFilterMonth, todayIso),
    [incidentFilterMonth, todayIso],
  )

  const incidentPdfDateBounds = useMemo(
    () => getMonthDateBounds(incidentPdfFilterMonth, todayIso),
    [incidentPdfFilterMonth, todayIso],
  )

  const incidentFilteredList = useMemo(() => {
    const filtered = appData.incidentReports.filter((record) => {
      if (incidentFilterChild && record.childId !== incidentFilterChild) {
        return false
      }
      if (incidentFilterDate) {
        return record.date === incidentFilterDate
      }
      return record.date.startsWith(incidentFilterMonth)
    })

    return filtered.sort((left, right) => {
      const dateCompare = right.date.localeCompare(left.date)
      if (dateCompare !== 0) {
        return dateCompare
      }
      return (right.updatedAt || right.createdAt || '').localeCompare(left.updatedAt || left.createdAt || '')
    })
  }, [
    appData.incidentReports,
    incidentFilterChild,
    incidentFilterDate,
    incidentFilterMonth,
  ])

  const incidentRecapTotals = useMemo(() => {
    const uniqueChildren = new Set(incidentFilteredList.map((record) => record.childId))
    return {
      totalChildren: uniqueChildren.size,
      totalReports: incidentFilteredList.length,
    }
  }, [incidentFilteredList])

  const incidentCompanionByChildDate = useMemo(() => {
    const map = new Map<string, { escortName: string; pickupName: string; sortKey: string }>()

    for (const record of appData.attendanceRecords) {
      const key = `${record.childId}-${record.date}`
      const sortKey = `${record.date}-${record.updatedAt || record.createdAt}`
      const current = map.get(key)
      if (!current || sortKey >= current.sortKey) {
        map.set(key, {
          escortName: record.escortName.trim(),
          pickupName: record.pickupName.trim(),
          sortKey,
        })
      }
    }

    return map
  }, [appData.attendanceRecords])

  const resolveIncidentReportsForPdf = useCallback(
    (mode: IncidentPdfMode, monthKey: string, dateKey: string) => {
      const filtered = appData.incidentReports.filter((record) => {
        if (incidentFilterChild && record.childId !== incidentFilterChild) {
          return false
        }
        if (mode === 'date') {
          return record.date === dateKey
        }
        return record.date.startsWith(monthKey)
      })

      return filtered.sort((left, right) => {
        const dateCompare = left.date.localeCompare(right.date)
        if (dateCompare !== 0) {
          return dateCompare
        }
        return (left.createdAt || '').localeCompare(right.createdAt || '')
      })
    },
    [appData.incidentReports, incidentFilterChild],
  )

  const handleDownloadIncidentPdf = async () => {
    const selectedMonth = clampMonthKeyToToday(incidentPdfFilterMonth || incidentFilterMonth)
    const selectedDate = clampOptionalDateKeyToToday(incidentPdfFilterDate)

    if (incidentPdfMode === 'date') {
      if (!selectedDate) {
        setIncidentPdfNotice({
          type: 'error',
          text: 'Pilih tanggal berita acara terlebih dahulu.',
        })
        return
      }
      if (!selectedDate.startsWith(selectedMonth)) {
        setIncidentPdfNotice({
          type: 'error',
          text: 'Tanggal harus berada pada bulan yang dipilih.',
        })
        return
      }
    }

    const reportsForPdf = resolveIncidentReportsForPdf(
      incidentPdfMode,
      selectedMonth,
      selectedDate,
    )
    if (reportsForPdf.length === 0) {
      setIncidentPdfNotice({
        type: 'error',
        text:
          incidentPdfMode === 'date'
            ? 'Tidak ada data berita acara pada tanggal yang dipilih.'
            : 'Tidak ada data berita acara pada bulan yang dipilih.',
      })
      return
    }

    setDownloadingIncidentPdf(true)
    setIncidentPdfNotice(null)

    try {
      const filterDate = incidentPdfMode === 'date' ? selectedDate : selectedMonth
      const result = await downloadBeritaAcaraPdf({
        filterDate,
        headerLabel: incidentPdfMode === 'month' ? formatMonthLabel(selectedMonth) : undefined,
        reports: reportsForPdf,
        attendanceRecords: appData.attendanceRecords,
        childrenData: appData.children,
        logoPath: `${import.meta.env.BASE_URL}UBAYA-noBG.png`,
      })

      setIncidentFilterMonth(selectedMonth)
      setIncidentFilterDate(incidentPdfMode === 'date' ? selectedDate : '')
      setIncidentPdfDialogOpen(false)

      if (!result.logoLoaded) {
        setIncidentPdfNotice({
          type: 'warning',
          text: `PDF berita acara berhasil diunduh (${result.pageCount} lembar), tetapi logo tidak ditemukan.`,
        })
        return
      }

      setIncidentPdfNotice({
        type: 'success',
        text: `PDF berita acara berhasil diunduh (${result.pageCount} lembar).`,
      })
    } catch {
      setIncidentPdfNotice({
        type: 'error',
        text: 'Gagal membuat PDF berita acara. Silakan coba lagi.',
      })
    } finally {
      setDownloadingIncidentPdf(false)
    }
  }

  const selectedStaffAttendanceDateLabel = useMemo(
    () => formatDateWithWeekday(staffAttendanceFilterDate),
    [staffAttendanceFilterDate],
  )

  const selectedStaffAttendanceMonthLabel = useMemo(
    () => formatMonthLabel(staffAttendanceFilterMonth),
    [staffAttendanceFilterMonth],
  )

  const staffAttendanceSummary = useMemo<StaffAttendanceSummary[]>(() => {
    return staffAttendanceRecapRows
      .map((row) => {
        const attendanceDateLabel = formatDateWithWeekday(
          row.attendanceDate || staffAttendanceFilterDate,
        )

        return {
          key: row.key || `${row.staffUserId}-${row.attendanceDate}`,
          staffUserId: row.staffUserId,
          fullName: row.fullName || 'Petugas',
          account: row.account || '-',
          attendanceDateLabel,
          checkInAt: row.checkInAt,
          checkOutAt: row.checkOutAt,
          dutyMinutes: calculateDutyMinutes(row.checkInAt, row.checkOutAt),
          monthlyAttendanceCount: Math.max(0, row.monthlyAttendanceCount),
        }
      })
      .sort((left, right) => left.fullName.localeCompare(right.fullName, 'id-ID'))
  }, [
    staffAttendanceFilterDate,
    staffAttendanceRecapRows,
  ])

  const staffAttendanceSummaryByStaffId = useMemo(
    () => new Map(staffAttendanceSummary.map((row) => [row.staffUserId, row])),
    [staffAttendanceSummary],
  )

  const staffAttendanceDailyRows = useMemo(() => {
    return [...staffUsers]
      .sort((left, right) => left.fullName.localeCompare(right.fullName, 'id-ID'))
      .map((staff) => {
        const summary = staffAttendanceSummaryByStaffId.get(staff.id) ?? null
        const checkInAt = summary?.checkInAt ?? ''
        const checkOutAt = summary?.checkOutAt ?? ''
        const dutyMinutes = calculateDutyMinutes(checkInAt, checkOutAt)
        const pay =
          dutyMinutes === null
            ? null
            : (() => {
              const { honor, transport } = calculateStaffPay(
                dutyMinutes / 60,
                calculateIsSenior(staff.createdAt),
              )
              return {
                honor,
                transport,
                total: honor + transport,
              }
            })()

        return {
          staff,
          summary,
          checkInAt,
          checkOutAt,
          dutyMinutes,
          pay,
        }
      })
  }, [staffAttendanceSummaryByStaffId, staffUsers])

  const staffBelumAbsenMasuk = useMemo(
    () => staffAttendanceDailyRows.filter((row) => !row.checkInAt),
    [staffAttendanceDailyRows],
  )

  const staffAbsenPulangRows = useMemo(
    () => staffAttendanceDailyRows.filter((row) => Boolean(row.checkInAt)),
    [staffAttendanceDailyRows],
  )

  const handleDownloadStaffAttendancePdf = () => {
    if (staffUsers.length === 0) {
      setStaffAttendancePdfNotice({
        type: 'error',
        text: 'Belum ada data petugas untuk diunduh.',
      })
      return
    }
    if (staffAttendancePdfMode === 'yearly' && !/^\d{4}$/.test(staffAttendancePdfYear)) {
      setStaffAttendancePdfNotice({
        type: 'error',
        text: 'Tahun unduhan harus diisi 4 digit.',
      })
      return
    }

    const HONOR_PER_DAY = 50000
    const TRANSPORT_PER_DAY = 20000
    setDownloadingStaffAttendancePdf(true)
    setStaffAttendancePdfNotice(null)

    try {
      const sortedStaff = [...staffUsers].sort((left, right) =>
        left.fullName.localeCompare(right.fullName, 'id-ID'),
      )

      const rows = sortedStaff.map((staff) => {
        const summary = staffAttendanceSummaryByStaffId.get(staff.id)
        const monthlyTotal = Math.max(0, summary?.monthlyAttendanceCount ?? 0)
        const dailyRow = staffAttendanceDailyRows.find((row) => row.staff.id === staff.id) ?? null

        if (staffAttendancePdfMode === 'daily') {
          return {
            fullName: staff.fullName,
            account: staff.email,
            attendanceDateLabel: selectedStaffAttendanceDateLabel,
            checkInTime: formatTimeOnly(dailyRow?.checkInAt ?? ''),
            checkOutTime: formatTimeOnly(dailyRow?.checkOutAt ?? ''),
            dutyDuration: formatDutyDuration(dailyRow?.dutyMinutes ?? null),
            monthlyAttendanceTotal: monthlyTotal,
            honor: dailyRow?.pay?.honor,
            transport: dailyRow?.pay?.transport,
          }
        }

        if (staffAttendancePdfMode === 'monthly') {
          return {
            fullName: staff.fullName,
            account: staff.email,
            attendanceDateLabel: selectedStaffAttendanceMonthLabel,
            checkInTime: '-',
            checkOutTime: '-',
            dutyDuration: '-',
            monthlyAttendanceTotal: monthlyTotal,
            honor: monthlyTotal * HONOR_PER_DAY,
            transport: monthlyTotal * TRANSPORT_PER_DAY,
          }
        }

        const estimatedYearlyAttendance = monthlyTotal * 12
        return {
          fullName: staff.fullName,
          account: staff.email,
          attendanceDateLabel: `Tahun ${staffAttendancePdfYear}`,
          checkInTime: '-',
          checkOutTime: '-',
          dutyDuration: '-',
          monthlyAttendanceTotal: estimatedYearlyAttendance,
          honor: estimatedYearlyAttendance * HONOR_PER_DAY,
          transport: estimatedYearlyAttendance * TRANSPORT_PER_DAY,
        }
      })

      const hasDataToDownload = rows.some((row) => row.monthlyAttendanceTotal > 0 || row.checkInTime !== '-')
      if (!hasDataToDownload) {
        setStaffAttendancePdfNotice({
          type: 'error',
          text: 'Belum ada data kehadiran petugas yang bisa diunduh untuk pilihan ini.',
        })
        return
      }

      downloadStaffAttendancePdf({
        filterDate: staffAttendancePdfMode === 'daily' ? staffAttendanceFilterDate : '',
        filterMonth:
          staffAttendancePdfMode === 'yearly'
            ? staffAttendancePdfYear
            : staffAttendanceFilterMonth,
        rows,
      })

      setStaffAttendancePdfDialogOpen(false)
      setStaffAttendancePdfNotice({
        type: 'success',
        text:
          staffAttendancePdfMode === 'daily'
            ? `PDF rekap harian ${selectedStaffAttendanceDateLabel} berhasil diunduh.`
            : staffAttendancePdfMode === 'monthly'
              ? `PDF rekap bulanan ${selectedStaffAttendanceMonthLabel} berhasil diunduh.`
              : `PDF rekap tahunan ${staffAttendancePdfYear} berhasil diunduh.`,
      })
    } catch {
      setStaffAttendancePdfNotice({
        type: 'error',
        text: 'Gagal membuat PDF rekap kehadiran petugas.',
      })
    } finally {
      setDownloadingStaffAttendancePdf(false)
    }
  }

  const serviceChildMap = useMemo(
    () => new Map(appData.children.map((child) => [child.id, child])),
    [appData.children],
  )

  const serviceRecapYearOptions = useMemo(() => {
    const years = new Set<string>([getLocalDateIso().slice(0, 4)])

    for (const record of appData.attendanceRecords) {
      const localDate = toLocalDateKey(record.date)
      if (!/^\d{4}-\d{2}-\d{2}$/.test(localDate)) {
        continue
      }
      years.add(localDate.slice(0, 4))
    }

    return Array.from(years).sort((left, right) => Number(right) - Number(left))
  }, [appData.attendanceRecords])

  useEffect(() => {
    if (serviceRecapYearOptions.includes(serviceRecapYear)) {
      return
    }

    setServiceRecapYear(serviceRecapYearOptions[0] ?? getLocalDateIso().slice(0, 4))
  }, [serviceRecapYear, serviceRecapYearOptions])

  const serviceMonthlyRecapRows = useMemo<ServiceMonthlyRecapRow[]>(() => {
    if (!/^\d{4}$/.test(serviceRecapYear)) {
      return []
    }

    const monthMap = new Map<
      string,
      {
        childIds: Set<string>
        serviceDayCounts: Record<ServicePackage, number>
      }
    >()

    for (let monthIndex = 1; monthIndex <= 12; monthIndex += 1) {
      const monthKey = `${serviceRecapYear}-${String(monthIndex).padStart(2, '0')}`
      monthMap.set(monthKey, {
        childIds: new Set<string>(),
        serviceDayCounts: createServicePackageCounter(),
      })
    }

    for (const record of appData.attendanceRecords) {
      const localDate = toLocalDateKey(record.date)
      if (!/^\d{4}-\d{2}-\d{2}$/.test(localDate)) {
        continue
      }

      const monthKey = localDate.slice(0, 7)
      const monthEntry = monthMap.get(monthKey)
      if (!monthEntry) {
        continue
      }

      const child = serviceChildMap.get(record.childId)
      if (!child) {
        continue
      }

      const servicePackage = child.servicePackage as ServicePackage
      monthEntry.childIds.add(child.id)
      monthEntry.serviceDayCounts[servicePackage] += 1
    }

    return Array.from(monthMap.entries()).map(([monthKey, monthEntry]) => {
      const packageCounts = createServicePackageCounter()

      for (const childId of monthEntry.childIds) {
        const child = serviceChildMap.get(childId)
        if (!child) {
          continue
        }
        const servicePackage = child.servicePackage as ServicePackage
        packageCounts[servicePackage] += 1
      }

      const totalServiceDays =
        monthEntry.serviceDayCounts.harian +
        monthEntry.serviceDayCounts['2-mingguan'] +
        monthEntry.serviceDayCounts.bulanan

      const estimatedCharge =
        packageCounts.bulanan * serviceRates.bulanan +
        packageCounts['2-mingguan'] * serviceRates['2-mingguan'] +
        packageCounts.harian * serviceRates.harian

      return {
        monthKey,
        monthLabel: formatMonthLabel(monthKey),
        totalChildren: monthEntry.childIds.size,
        packageCounts,
        serviceDayCounts: monthEntry.serviceDayCounts,
        totalServiceDays,
        estimatedCharge,
      }
    })
  }, [appData.attendanceRecords, serviceChildMap, serviceRates, serviceRecapYear])

  useEffect(() => {
    if (serviceMonthlyRecapRows.some((row) => row.monthKey === serviceRecapMonth)) {
      return
    }

    const fallbackMonth =
      serviceMonthlyRecapRows.find((row) => row.totalServiceDays > 0)?.monthKey ??
      serviceMonthlyRecapRows[0]?.monthKey

    if (fallbackMonth) {
      setServiceRecapMonth(fallbackMonth)
    }
  }, [serviceMonthlyRecapRows, serviceRecapMonth])

  const selectedServiceMonthlyRecap = useMemo(
    () =>
      serviceMonthlyRecapRows.find((row) => row.monthKey === serviceRecapMonth) ??
      serviceMonthlyRecapRows[0] ??
      null,
    [serviceMonthlyRecapRows, serviceRecapMonth],
  )

  const serviceMonthlyDetail = useMemo<ServiceMonthlyDetail | null>(() => {
    if (!selectedServiceMonthlyRecap) {
      return null
    }

    const attendanceByChild = new Map<string, number>()
    for (const record of appData.attendanceRecords) {
      const localDate = toLocalDateKey(record.date)
      if (!/^\d{4}-\d{2}-\d{2}$/.test(localDate)) {
        continue
      }
      if (localDate.slice(0, 7) !== selectedServiceMonthlyRecap.monthKey) {
        continue
      }
      attendanceByChild.set(record.childId, (attendanceByChild.get(record.childId) ?? 0) + 1)
    }

    const byPackage: Record<ServicePackage, ServiceMonthChildRow[]> = {
      harian: [],
      '2-mingguan': [],
      bulanan: [],
    }

    const genderCounts: Record<ServiceGenderKey, number> = {
      L: 0,
      P: 0,
      other: 0,
    }

    for (const [childId, attendanceCount] of attendanceByChild.entries()) {
      const child = serviceChildMap.get(childId)
      if (!child) {
        continue
      }

      const servicePackage = child.servicePackage as ServicePackage
      const genderKey = resolveServiceGenderKey(child.gender)
      genderCounts[genderKey] += 1
      byPackage[servicePackage].push({
        childName: child.fullName,
        attendanceCount,
        genderKey,
      })
    }

    for (const option of servicePackageOptions) {
      byPackage[option.value as ServicePackage].sort((left: ServiceMonthChildRow, right: ServiceMonthChildRow) =>
        left.childName.localeCompare(right.childName, 'id-ID'),
      )
    }

    return {
      monthKey: selectedServiceMonthlyRecap.monthKey,
      monthLabel: selectedServiceMonthlyRecap.monthLabel,
      totalChildren: attendanceByChild.size,
      genderCounts,
      byPackage,
    }
  }, [appData.attendanceRecords, selectedServiceMonthlyRecap, serviceChildMap])

  const serviceMonthlyDetailMaxRows = useMemo(() => {
    if (!serviceMonthlyDetail) {
      return 0
    }

    return Math.max(
      1,
      ...servicePackageOptions.map(
        (option) => serviceMonthlyDetail.byPackage[option.value as ServicePackage].length,
      ),
    )
  }, [serviceMonthlyDetail])

  void serviceMonthlyDetailMaxRows

  const serviceBillingArrearsRows = useMemo<ServiceBillingArrearsRow[]>(
    () =>
      (serviceBillingSummary?.rows ?? [])
        .filter((row) => row.totalOutstanding > 0)
        .map((row) => ({
          childId: row.childId,
          childName: row.childName,
          packageKey: row.displayServicePackage,
          packageLabel: servicePackageLabels[row.displayServicePackage],
          unpaidAttendanceDays: toUnpaidAttendanceDays(
            row,
            serviceBillingSummary?.rates ?? serviceRates,
          ),
          totalOutstanding: Math.max(0, Math.round(row.totalOutstanding)),
          activePeriodId: row.activePeriod?.id ?? '',
          currentServicePackage: row.currentServicePackage,
          isMigrated: row.migrationInfo !== null,
        }))
        .sort((left: ServiceBillingArrearsRow, right: ServiceBillingArrearsRow) => {
          if (left.totalOutstanding !== right.totalOutstanding) {
            return right.totalOutstanding - left.totalOutstanding
          }
          return left.childName.localeCompare(right.childName, 'id-ID')
        }),
    [serviceBillingSummary?.rates, serviceBillingSummary?.rows, serviceRates],
  )

  const serviceBillingPaidRows = useMemo(
    () => {
      const filteredAndSorted = (serviceBillingSummary?.rows ?? [])
        .filter((row) => {
          // Lunas = tidak punya tunggakan
          if (row.totalOutstanding > 0) return false

          // Tetap tampilkan jika dia punya periode aktif ATAU jika sudah pernah bayar sesuatu
          const hasPeriod = row.status !== 'belum-periode'
          const hasPaidInfo = row.paidPeriod > 0 || row.paidArrears > 0 || row.arrearsAttendanceDays > 0
          if (!hasPeriod && !hasPaidInfo) return false

          if (serviceBillingPaidMonth && row.lastPaymentAt) {
            // lastPaymentAt format is ISO like YYYY-MM-DDTHH:mm:ssZ
            if (!row.lastPaymentAt.startsWith(serviceBillingPaidMonth)) return false
          }

          if (serviceBillingPaidPackage) {
            if (row.displayServicePackage !== serviceBillingPaidPackage) return false
          }

          return true
        })
        .map((row) => ({
          childId: row.childId,
          childName: row.childName,
          packageKey: row.displayServicePackage,
          packageLabel: servicePackageLabels[row.displayServicePackage],
          paidAmount: Math.max(0, Math.round(row.paidPeriod + row.paidArrears)),
          isMigrated: row.migrationInfo !== null,
        }))
        .sort((left, right) => {
          const leftPkgIdx = servicePackageTableOrder.indexOf(left.packageKey)
          const rightPkgIdx = servicePackageTableOrder.indexOf(right.packageKey)
          if (leftPkgIdx !== rightPkgIdx) return leftPkgIdx - rightPkgIdx
          return left.childName.localeCompare(right.childName, 'id-ID')
        })

      return filteredAndSorted.slice(0, serviceBillingPaidLimit)
    },
    [serviceBillingSummary?.rows, serviceBillingPaidMonth, serviceBillingPaidPackage, serviceBillingPaidLimit],
  )

  const serviceBillingArrearsChildOptions = useMemo(
    () =>
      serviceBillingArrearsRows.map((row) => ({
        value: row.childId,
        label: `${row.childName} · ${row.packageLabel}`,
        badge: `${row.unpaidAttendanceDays} hari belum lunas`,
      })),
    [serviceBillingArrearsRows],
  )

  const selectedServiceBillingSummary = useMemo(
    () =>
      serviceBillingSummary?.rows.find((row) => row.childId === selectedBillingChildId) ??
      null,
    [selectedBillingChildId, serviceBillingSummary?.rows],
  )

  const selectedServiceBillingArrearsRow = useMemo(
    () =>
      serviceBillingArrearsRows.find((row) => row.childId === selectedBillingChildId) ??
      null,
    [selectedBillingChildId, serviceBillingArrearsRows],
  )

  const selectedServiceBillingPeriods = serviceBillingHistory?.periods ?? []
  const selectedServiceBillingTransactions = serviceBillingHistory?.transactions ?? []

  useEffect(() => {
    if (serviceBillingArrearsRows.length === 0) {
      return
    }
    const hasSelectedArrears = serviceBillingArrearsRows.some(
      (row) => row.childId === selectedBillingChildId,
    )
    if (hasSelectedArrears) {
      return
    }
    handleSelectServiceBillingArrearsChild(serviceBillingArrearsRows[0].childId)
  }, [
    handleSelectServiceBillingArrearsChild,
    selectedBillingChildId,
    serviceBillingArrearsRows,
  ])

  const unusedServiceBillingAdvancedRefs = {
    handleCreateBillingPeriod,
    handleCreateBillingPayment,
    handleCreateBillingRefund,
    selectedServiceBillingPeriods,
    selectedServiceBillingTransactions,
  }
  void unusedServiceBillingAdvancedRefs

  // --- Render sub-tab pills ---
  const renderSubTabPills = () => {
    if (activeSidebar === 'monitoring') {
      return (
        <div className="admin-monitoring-lane">
          <div className="admin-monitoring-tabs" role="tablist" aria-label="Menu Rekap Admin">
            {monitoringSubTabs.map((tab) => (
              <button
                key={tab.key}
                type="button"
                className={`admin-monitoring-tab ${monitoringTab === tab.key ? 'is-active' : ''}`}
                onClick={() => {
                  setMonitoringTab(tab.key)
                  setMessage(null)
                  setErrorMessage(null)
                }}
                aria-pressed={monitoringTab === tab.key}
              >
                <span className="admin-monitoring-tab__icon" aria-hidden="true">
                  <tab.icon size={18} />
                </span>
                <span className="admin-monitoring-tab__content">
                  <span className="admin-monitoring-tab__label">{tab.label}</span>
                  <span className="admin-monitoring-tab__desc">{tab.description}</span>
                </span>
              </button>
            ))}
          </div>
        </div>
      )
    }

    if (activeSidebar === 'settings') {
      return (
        <div className="admin-monitoring-lane admin-monitoring-lane--settings">
          <div className="admin-monitoring-tabs" role="tablist" aria-label="Menu Pengaturan Admin">
            {settingsSubTabs.map((tab) => (
              <button
                key={tab.key}
                type="button"
                className={`admin-monitoring-tab ${settingsTab === tab.key ? 'is-active' : ''}`}
                onClick={() => {
                  setSettingsTab(tab.key)
                  setMessage(null)
                  setErrorMessage(null)
                }}
                aria-pressed={settingsTab === tab.key}
              >
                <span className="admin-monitoring-tab__icon" aria-hidden="true">
                  <tab.icon size={18} />
                </span>
                <span className="admin-monitoring-tab__content">
                  <span className="admin-monitoring-tab__label">{tab.label}</span>
                  <span className="admin-monitoring-tab__desc">{tab.description}</span>
                </span>
              </button>
            ))}
          </div>
        </div>
      )
    }
  }

  const renderContent = () => {
    if (activeSidebar === 'monitoring') {
      switch (monitoringTab) {
        case 'kehadiran-anak': {
          const kehadiranFilteredRecords = appData.attendanceRecords
            .filter(r => r.date.startsWith(staffAttendanceFilterMonth))
            .sort((a, b) => b.date.localeCompare(a.date))
          const kehadiranTotalPages = Math.max(1, Math.ceil(kehadiranFilteredRecords.length / KEHADIRAN_ANAK_PAGE_SIZE))
          const kehadiranPageStart = (kehadiranAnakPage - 1) * KEHADIRAN_ANAK_PAGE_SIZE
          const kehadiranPagedRecords = kehadiranFilteredRecords.slice(kehadiranPageStart, kehadiranPageStart + KEHADIRAN_ANAK_PAGE_SIZE)

          const handleDownloadKehadiranAnakPdf = async () => {
            setDownloadingKehadiranAnakPdf(true)
            setKehadiranAnakPdfNotice(null)
            try {
              const monthKey = staffAttendanceFilterMonth
              const parsed = monthKey.split('-')
              const year = Number(parsed[0])
              const monthIndex = Number(parsed[1]) - 1
              const daysInMonth = new Date(year, monthIndex + 1, 0).getDate()
              const monthPrefix = monthKey
              const weekdays: string[] = []
              for (let day = 1; day <= daysInMonth; day++) {
                const date = new Date(year, monthIndex, day)
                const dow = date.getDay()
                if (dow >= 1 && dow <= 5) weekdays.push(`${monthPrefix}-${String(day).padStart(2, '0')}`)
              }
              const sortedChildren = [...appData.children].sort((a, b) => a.fullName.localeCompare(b.fullName, 'id', { sensitivity: 'base' }))
              const attendanceDateMap = new Map<string, Set<string>>()
              for (const record of appData.attendanceRecords) {
                if (!record.date.startsWith(monthKey)) continue
                if (!record.arrivalTime && !record.departureTime) continue
                const dates = attendanceDateMap.get(record.childId) ?? new Set<string>()
                dates.add(record.date)
                attendanceDateMap.set(record.childId, dates)
              }
              const rows = sortedChildren.map(child => {
                const attendedDates = attendanceDateMap.get(child.id) ?? new Set<string>()
                const attendanceByDate: Record<string, boolean> = {}
                let totalAttendance = 0
                for (const date of weekdays) {
                  const isPresent = attendedDates.has(date)
                  attendanceByDate[date] = isPresent
                  if (isPresent) totalAttendance++
                }
                const packageLabels: Record<string, string> = { harian: 'Harian', '2-mingguan': '2 Mingguan', bulanan: 'Bulanan' }
                return { childName: child.fullName, packageLabel: packageLabels[child.servicePackage] ?? child.servicePackage, attendanceByDate, totalAttendance }
              })
              const totalByDate = weekdays.map(date => rows.reduce((sum, row) => sum + (row.attendanceByDate[date] ? 1 : 0), 0))
              const grandTotal = totalByDate.reduce((s, v) => s + v, 0)
              const monthNames = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']
              const monthLabel = `${monthNames[monthIndex]} ${year}`
              const result = await downloadRekapAttendancePdf({
                selectedMonth: monthKey, monthLabel, internalHolidayDates: [], workingDates: weekdays,
                rows, totalByDate, grandTotal, logoPath: `${import.meta.env.BASE_URL}UBAYA-noBG.png`,
              })
              setKehadiranAnakPdfNotice({ type: result.logoLoaded ? 'success' : 'warning', text: result.logoLoaded ? 'PDF rekap kehadiran anak berhasil diunduh.' : 'PDF berhasil diunduh, tetapi logo tidak ditemukan.' })
            } catch {
              setKehadiranAnakPdfNotice({ type: 'error', text: 'Gagal membuat PDF rekap kehadiran anak.' })
            } finally {
              setDownloadingKehadiranAnakPdf(false)
            }
          }

          return (
            <section className="page">
              <div className="card">
                <div className="card__header">
                  <h2>Riwayat Kehadiran Anak Bulanan</h2>
                </div>
                {kehadiranAnakPdfNotice ? (
                  <p className={`download-note download-note--${kehadiranAnakPdfNotice.type}`}>{kehadiranAnakPdfNotice.text}</p>
                ) : null}
                <div className="inline-row" style={{ marginBottom: '1.5rem' }}>
                  <div className="field-group" style={{ maxWidth: '200px' }}>
                    <label className="label">Bulan</label>
                    <input
                      type="month"
                      className="input"
                      value={staffAttendanceFilterMonth}
                      max={clampMonthKeyToToday(staffAttendanceFilterMonth)}
                      onChange={(e) => { setStaffAttendanceFilterMonth(e.target.value); setKehadiranAnakPage(1) }}
                    />
                  </div>
                  <button
                    type="button"
                    className="button"
                    onClick={() => void handleDownloadKehadiranAnakPdf()}
                    disabled={isDownloadingKehadiranAnakPdf || kehadiranFilteredRecords.length === 0}
                  >
                    {isDownloadingKehadiranAnakPdf ? 'Membuat PDF...' : 'Download PDF'}
                  </button>
                </div>
                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Nama Anak</th>
                        <th>Tanggal</th>
                        <th>Kondisi Datang</th>
                        <th>Kondisi Pulang</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {isLoadingServices ? (
                        <tr><td colSpan={5} className="table__empty">Memuat...</td></tr>
                      ) : kehadiranFilteredRecords.length === 0 ? (
                        <tr><td colSpan={5} className="table__empty">Tidak ada data untuk bulan ini.</td></tr>
                      ) : (
                        kehadiranPagedRecords.map(record => (
                          <tr key={record.id}>
                            <td>{childNameById[record.childId] || 'Data Terhapus'}</td>
                            <td>{formatDateWithWeekday(record.date)}</td>
                            <td>{record.arrivalPhysicalCondition}/{record.arrivalEmotionalCondition}</td>
                            <td>{record.departurePhysicalCondition}/{record.departureEmotionalCondition}</td>
                            <td>{record.departureTime ? 'Sudah Pulang' : 'Masih di TPA'}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                {kehadiranFilteredRecords.length > 0 ? (
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '0.75rem', fontSize: '0.9rem' }}>
                    <span style={{ color: 'var(--color-text-muted, #718096)' }}>Halaman {kehadiranAnakPage} dari {kehadiranTotalPages} ({kehadiranFilteredRecords.length} data)</span>
                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                      <button type="button" className="button button--tiny button--ghost" disabled={kehadiranAnakPage <= 1} onClick={() => setKehadiranAnakPage(p => Math.max(1, p - 1))}>← Previous</button>
                      <button type="button" className="button button--tiny button--ghost" disabled={kehadiranAnakPage >= kehadiranTotalPages} onClick={() => setKehadiranAnakPage(p => Math.min(kehadiranTotalPages, p + 1))}>Next →</button>
                    </div>
                  </div>
                ) : null}
              </div>
            </section>
          )
        }

        case 'observasi-anak': {
          const handleDownloadObservationChildPdf = async (childId: string) => {
            const childRecords = resolveObservationMonthlyRecordsByChild(childId)
            if (childRecords.length === 0) {
              setObservationPdfNotice({
                type: 'warning',
                text: 'Tidak ada data observasi untuk anak dan bulan yang dipilih.',
              })
              return
            }

            setDownloadingObservationChildId(childId)
            setObservationPdfNotice(null)
            try {
              const result = await downloadObservationBatchPdf({
                filterDate: observationFilterDate || observationFilterMonth,
                filterGroupLabel: selectedObservationGroupLabel || '-',
                records: childRecords,
                childrenData: appData.children,
                logoPath: `${import.meta.env.BASE_URL}UBAYA-noBG.png`,
              })

              setObservationPdfNotice({
                type: result.logoLoaded ? 'success' : 'warning',
                text: result.logoLoaded
                  ? `Data observasi berhasil diunduh (${result.pageCount} lembar).`
                  : `Data observasi berhasil diunduh (${result.pageCount} lembar), tetapi logo tidak ditemukan.`,
              })
            } catch {
              setObservationPdfNotice({
                type: 'error',
                text: 'Gagal membuat PDF observasi.',
              })
            } finally {
              setDownloadingObservationChildId(null)
            }
          }

          const handleDownloadObservationAll = async () => {
            if (!observationFilterChild || !observationFilterGroup) {
              return
            }

            const childRecords = resolveObservationMonthlyRecordsByChild(observationFilterChild)
            if (childRecords.length === 0) {
              setObservationPdfNotice({
                type: 'warning',
                text: 'Tidak ada data observasi untuk anak dan bulan yang dipilih.',
              })
              return
            }

            setDownloadingObservationPdf(true)
            setObservationPdfNotice(null)
            try {
              const result = await downloadObservationBatchPdf({
                filterDate: observationFilterDate || observationFilterMonth,
                filterGroupLabel: selectedObservationGroupLabel || '-',
                records: childRecords,
                childrenData: appData.children,
                logoPath: `${import.meta.env.BASE_URL}UBAYA-noBG.png`,
              })

              setObservationPdfNotice({
                type: result.logoLoaded ? 'success' : 'warning',
                text: result.logoLoaded
                  ? `Unduh semua observasi berhasil (${result.pageCount} lembar).`
                  : `Unduh semua observasi berhasil (${result.pageCount} lembar), tetapi logo tidak ditemukan.`,
              })
            } catch {
              setObservationPdfNotice({
                type: 'error',
                text: 'Gagal membuat PDF observasi.',
              })
            } finally {
              setDownloadingObservationPdf(false)
            }
          }

          return (
            <section className="page">
              <div className="card">
                <div className="card__header">
                  <h2>Ringkasan Observasi Per Anak</h2>
                  <p className="card__description">Jika tanggal kosong, data tampil 1 bulan penuh dengan urutan terbaru.</p>
                </div>

                {observationPdfNotice ? (
                  <div className={`notice notice--${observationPdfNotice.type}`} style={{ marginBottom: '1rem' }}>
                    {observationPdfNotice.text}
                  </div>
                ) : null}

                <div className="form-grid form-grid--3" style={{ marginBottom: '1rem' }}>
                  <div className="field-group">
                    <label className="label">Filter Bulan</label>
                    <input
                      type="month"
                      className="input"
                      value={observationFilterMonth}
                      max={clampMonthKeyToToday(observationFilterMonth)}
                      onChange={(event) => handleObservationMonthFilterChange(event.target.value)}
                    />
                  </div>
                  <div className="field-group">
                    <label className="label">Filter Tanggal (Opsional)</label>
                    <input
                      type="date"
                      className="input"
                      value={observationFilterDate}
                      min={observationDateBounds.min}
                      max={observationDateBounds.max}
                      onChange={(event) => handleObservationDateFilterChange(event.target.value)}
                    />
                  </div>
                  <div className="field-group">
                    <label className="label">Filter Kelompok</label>
                    <select
                      className="input"
                      value={observationFilterGroup}
                      onChange={(event) => handleObservationGroupFilterChange(event.target.value)}
                    >
                      <option value="">-- Semua Kelompok --</option>
                      {observationGroupOptions.map((option) => (
                        <option key={option.value} value={option.value}>{option.label}</option>
                      ))}
                    </select>
                  </div>
                  <div className="field-group">
                    <label className="label">Nama Anak</label>
                    <select
                      className="input"
                      value={observationFilterChild}
                      onChange={(event) => setObservationFilterChild(event.target.value)}
                    >
                      <option value="">-- Semua Anak --</option>
                      {appData.children
                        .slice()
                        .sort((left, right) => left.fullName.localeCompare(right.fullName, 'id-ID'))
                        .map((child) => (
                          <option key={child.id} value={child.id}>{child.fullName}</option>
                        ))}
                    </select>
                  </div>
                </div>

                {canDownloadObservationAll ? (
                  <div className="inline-row" style={{ marginBottom: '1rem' }}>
                    <button
                      type="button"
                      className="button"
                      onClick={() => void handleDownloadObservationAll()}
                      disabled={isDownloadingObservationPdf}
                    >
                      {isDownloadingObservationPdf ? 'Mengunduh...' : 'Unduh Semua'}
                    </button>
                  </div>
                ) : null}

                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Tanggal Observasi</th>
                        <th>Nama Anak</th>
                        <th>Sudah Baik</th>
                        <th>Perlu Latihan</th>
                        <th>Perlu Arahan</th>
                        <th>Kelompok</th>
                        <th>Unduh</th>
                      </tr>
                    </thead>
                    <tbody>
                      {isLoadingServices ? (
                        <tr><td colSpan={7} className="table__empty">Memuat...</td></tr>
                      ) : sortedObservationRecapRows.length === 0 ? (
                        <tr><td colSpan={7} className="table__empty">Tidak ada data observasi.</td></tr>
                      ) : (
                        sortedObservationRecapRows.map((row) => (
                          <tr key={row.childId}>
                            <td>{formatDateOnly(row.latestDate)}</td>
                            <td>{row.childName}</td>
                            <td>{row.categorySummary.sudahBaik}</td>
                            <td>{row.categorySummary.perluLatihan}</td>
                            <td>{row.categorySummary.perluArahan}</td>
                            <td>{row.latestGroup}</td>
                            <td>
                              <button
                                type="button"
                                className="button button--ghost button--tiny"
                                onClick={() => void handleDownloadObservationChildPdf(row.childId)}
                                disabled={
                                  downloadingObservationChildId === row.childId ||
                                  !observationChildIdsWithMonthlyRecords.has(row.childId)
                                }
                              >
                                {downloadingObservationChildId === row.childId ? '...' : 'Unduh'}
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          )
        }

        case 'berita-acara': {
          const incidentRows = incidentFilteredList.slice(0, 20)

          return (
            <section className="page">
              <div className="card">
                <div className="card__header">
                  <h2>Berita Acara</h2>
                  <p className="card__description">
                    Total <strong>{incidentRecapTotals.totalReports}</strong> berita acara dari <strong>{incidentRecapTotals.totalChildren}</strong> anak.
                  </p>
                </div>

                {incidentPdfNotice ? (
                  <div className={`notice notice--${incidentPdfNotice.type}`} style={{ marginBottom: '1rem' }}>
                    {incidentPdfNotice.text}
                  </div>
                ) : null}

                <div className="inline-row inline-row--wrap" style={{ marginBottom: '1.5rem', alignItems: 'flex-end' }}>
                  <div className="field-group" style={{ maxWidth: '200px' }}>
                    <label className="label">Filter Bulan</label>
                    <input
                      type="month"
                      className="input"
                      value={incidentFilterMonth}
                      max={clampMonthKeyToToday(incidentFilterMonth)}
                      onChange={(event) => handleIncidentMonthFilterChange(event.target.value)}
                    />
                  </div>
                  <div className="field-group" style={{ maxWidth: '220px' }}>
                    <label className="label">Filter Tanggal (Opsional)</label>
                    <input
                      type="date"
                      className="input"
                      value={incidentFilterDate}
                      min={incidentDateBounds.min}
                      max={incidentDateBounds.max}
                      onChange={(event) => handleIncidentDateFilterChange(event.target.value)}
                    />
                  </div>
                  <div className="field-group" style={{ maxWidth: '260px' }}>
                    <label className="label">Filter Anak</label>
                    <select
                      className="input"
                      value={incidentFilterChild}
                      onChange={(event) => setIncidentFilterChild(event.target.value)}
                    >
                      <option value="">-- Semua Anak --</option>
                      {appData.children
                        .slice()
                        .sort((left, right) => left.fullName.localeCompare(right.fullName, 'id-ID'))
                        .map((child) => (
                        <option key={child.id} value={child.id}>{child.fullName}</option>
                      ))}
                    </select>
                  </div>
                  <button
                    type="button"
                    className="button"
                    style={{ marginLeft: 'auto' }}
                    onClick={openIncidentPdfDialog}
                    disabled={isDownloadingIncidentPdf}
                  >
                    {isDownloadingIncidentPdf ? 'Mengunduh...' : 'Unduh PDF'}
                  </button>
                </div>

                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Nama Anak</th>
                        <th>Tanggal Berita Acara</th>
                        <th>Pesan dari Orang Tua</th>
                        <th>Untuk Orang Tua</th>
                        <th>Pendamping Pagi</th>
                        <th>Pendamping Siang</th>
                      </tr>
                    </thead>
                    <tbody>
                      {isLoadingServices ? (
                        <tr><td colSpan={6} className="table__empty">Memuat...</td></tr>
                      ) : incidentFilteredList.length === 0 ? (
                        <tr><td colSpan={6} className="table__empty">Tidak ada berita acara.</td></tr>
                      ) : (
                        incidentRows.map((report) => {
                          const companion = incidentCompanionByChildDate.get(`${report.childId}-${report.date}`)
                          return (
                            <tr key={report.id}>
                              <td>{childNameById[report.childId] || 'Data Terhapus'}</td>
                              <td>{formatDateOnly(report.date)}</td>
                              <td>{report.parentMessage || '-'}</td>
                              <td>{report.messageForParent || '-'}</td>
                              <td>{companion?.escortName || '-'}</td>
                              <td>{companion?.pickupName || '-'}</td>
                            </tr>
                          )
                        })
                      )}
                    </tbody>
                  </table>
                </div>
                {incidentFilteredList.length > 20 ? (
                  <p className="field-hint" style={{ marginTop: '0.5rem' }}>
                    Menampilkan 20 dari {incidentFilteredList.length} data. Gunakan filter untuk mempersempit.
                  </p>
                ) : null}
              </div>
            </section>
          )
        }

        case 'kehadiran-petugas': {
          return (
            <section className="page">
              <div className="card">
                <div className="card__header">
                  <h2>Rekap Kehadiran Petugas</h2>
                  <p className="card__description">{selectedStaffAttendanceDateLabel}</p>
                </div>

                {staffAttendancePdfNotice ? (
                  <div className={`notice notice--${staffAttendancePdfNotice.type}`} style={{ marginBottom: '1rem' }}>
                    {staffAttendancePdfNotice.text}
                  </div>
                ) : null}

                <div className="inline-row inline-row--wrap" style={{ marginBottom: '1rem', alignItems: 'flex-end' }}>
                  <div className="field-group" style={{ maxWidth: '200px' }}>
                    <label className="label">Bulan</label>
                    <input
                      type="month"
                      className="input"
                      value={staffAttendanceFilterMonth}
                      max={clampMonthKeyToToday(staffAttendanceFilterMonth)}
                      onChange={(event) => handleStaffAttendanceMonthFilterChange(event.target.value)}
                    />
                  </div>
                  <div className="field-group" style={{ maxWidth: '220px' }}>
                    <label className="label">Tanggal (Harian)</label>
                    <input
                      type="date"
                      className="input"
                      value={staffAttendanceFilterDate}
                      min={getMonthDateBounds(staffAttendanceFilterMonth, todayIso).min}
                      max={getMonthDateBounds(staffAttendanceFilterMonth, todayIso).max}
                      onChange={(event) => handleStaffAttendanceDateFilterChange(event.target.value)}
                    />
                  </div>
                  <button
                    type="button"
                    className="button"
                    style={{ marginLeft: 'auto' }}
                    onClick={openStaffAttendancePdfDialog}
                    disabled={isDownloadingStaffAttendancePdf}
                  >
                    {isDownloadingStaffAttendancePdf ? 'Mengunduh...' : 'Unduh PDF'}
                  </button>
                </div>

                <div className="admin-summary-grid admin-summary-grid--three" style={{ marginBottom: '1rem' }}>
                  <div className="admin-summary-card">
                    <p className="admin-summary-card__label">Card Absen Masuk</p>
                    {staffBelumAbsenMasuk.length === 0 ? (
                      <span>Semua petugas sudah absen masuk.</span>
                    ) : (
                      staffBelumAbsenMasuk.map((row) => (
                        <span key={row.staff.id}>{row.staff.fullName}</span>
                      ))
                    )}
                  </div>
                  <div className="admin-summary-card">
                    <p className="admin-summary-card__label">Card Absen Pulang</p>
                    {staffAbsenPulangRows.length === 0 ? (
                      <span>Belum ada petugas yang absen masuk.</span>
                    ) : (
                      staffAbsenPulangRows.map((row) => (
                        <span key={row.staff.id}>
                          {row.staff.fullName} - {row.checkOutAt ? 'Pulang' : 'Menunggu pulang'}
                        </span>
                      ))
                    )}
                  </div>
                  <div className="admin-summary-card">
                    <p className="admin-summary-card__label">Keterangan</p>
                    <span>Honor dan transport muncul setelah petugas absen pulang.</span>
                  </div>
                </div>

                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Nama Petugas</th>
                        <th>Absen Datang</th>
                        <th>Absen Pulang</th>
                        <th>Durasi</th>
                        <th>Honor</th>
                        <th>Transport</th>
                        <th>Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {isLoadingStaffAttendance ? (
                        <tr><td colSpan={7} className="table__empty">Memuat...</td></tr>
                      ) : staffAttendanceDailyRows.length === 0 ? (
                        <tr><td colSpan={7} className="table__empty">Tidak ada data petugas.</td></tr>
                      ) : (
                        staffAttendanceDailyRows.map((row) => (
                          <tr key={row.staff.id}>
                            <td>{row.staff.fullName}</td>
                            <td>{formatTimeOnly(row.checkInAt)}</td>
                            <td>{formatTimeOnly(row.checkOutAt)}</td>
                            <td>{row.checkOutAt ? formatDutyDuration(row.dutyMinutes) : '-'}</td>
                            <td>{row.pay ? formatRupiah(row.pay.honor) : '-'}</td>
                            <td>{row.pay ? formatRupiah(row.pay.transport) : '-'}</td>
                            <td>{row.pay ? formatRupiah(row.pay.total) : '-'}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          )
        }
        case 'layanan':
          return (
            <section className="page">
              <div className="card">
                <div className="card__header-with-actions" style={{ marginBottom: '1.5rem' }}>
                  <div>
                    <h2>Penagihan & Pelunasan Layanan</h2>
                    <p className="card__description">Kelola tunggakan dan proses pembayaran anak</p>
                  </div>
                </div>

                <details
                  className="service-section-collapse"
                  open={isServiceBillingSettlementOpen}
                  onToggle={(event) =>
                    setServiceBillingSettlementOpen(
                      (event.currentTarget as HTMLDetailsElement).open,
                    )
                  }
                >
                  <summary className="service-section-collapse__summary">
                    Input Pembayaran (Pelunasan)
                  </summary>

                  <div className="service-section-collapse__body">
                    <div className="form-grid form-grid--2 service-billing-settlement-grid">
                      <div className="field-group">
                        <label className="label">Pilih Anak yang Belum Lunas</label>
                        <SearchableSelect
                          value={selectedBillingChildId}
                          onChange={handleSelectServiceBillingArrearsChild}
                          options={serviceBillingArrearsChildOptions}
                          placeholder="Pilih anak yang belum lunas"
                          emptyMessage="Tidak ada anak yang belum lunas"
                          clearable={false}
                          usePortal
                        />
                      </div>

                      <div className="field-group">
                        <label className="label" htmlFor="serviceBillingAmount">
                          Nominal Pembayaran
                        </label>
                        <input
                          id="serviceBillingAmount"
                          className="input service-billing-amount-input"
                          type="text"
                          inputMode="numeric"
                          value={servicePaymentAmountText}
                          onChange={(event) =>
                            handleServicePaymentAmountInput(event.target.value)
                          }
                          onBlur={handleServicePaymentAmountBlur}
                          disabled={!selectedServiceBillingArrearsRow || isMutatingServiceBilling}
                        />
                      </div>
                    </div>

                    <div className="form-grid form-grid--3 service-billing-settlement-grid">
                      <div className="field-group">
                        <label className="label">Bukti Transfer</label>
                        <input
                          id="serviceBillingPaymentProof"
                          type="file"
                          accept="image/*"
                          onChange={(event) => void handleServicePaymentProofChange(event)}
                          disabled={!selectedServiceBillingArrearsRow || isMutatingServiceBilling}
                          style={{ display: 'none' }}
                        />
                        <div
                          role="button"
                          tabIndex={0}
                          onClick={() => {
                            if (!selectedServiceBillingArrearsRow || isMutatingServiceBilling) return
                            document.getElementById('serviceBillingPaymentProof')?.click()
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              e.preventDefault()
                              if (!selectedServiceBillingArrearsRow || isMutatingServiceBilling) return
                              document.getElementById('serviceBillingPaymentProof')?.click()
                            }
                          }}
                          style={{
                            width: '100px',
                            height: '100px',
                            border: '2px dashed var(--color-border, #cbd5e0)',
                            borderRadius: '8px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: (!selectedServiceBillingArrearsRow || isMutatingServiceBilling) ? 'not-allowed' : 'pointer',
                            overflow: 'hidden',
                            backgroundColor: 'var(--color-bg-subtle, #f7fafc)',
                            opacity: (!selectedServiceBillingArrearsRow || isMutatingServiceBilling) ? 0.5 : 1,
                          }}
                        >
                          {serviceBillingPaymentForm.paymentProofDataUrl ? (
                            <img
                              src={serviceBillingPaymentForm.paymentProofDataUrl}
                              alt="Bukti transfer"
                              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                            />
                          ) : (
                            <span style={{ fontSize: '2rem', color: 'var(--color-text-muted, #a0aec0)' }}>📷</span>
                          )}
                        </div>
                        {serviceBillingPaymentForm.paymentProofDataUrl ? (
                          <button
                            type="button"
                            className="button button--tiny button--ghost"
                            onClick={clearServicePaymentProof}
                            disabled={isMutatingServiceBilling}
                            style={{ marginTop: '4px' }}
                          >
                            Hapus Bukti
                          </button>
                        ) : null}
                      </div>

                      <div className="field-group">
                        <label className="label" htmlFor="serviceBillingNotes">
                          Metode Pembayaran
                        </label>
                        <select
                          id="serviceBillingNotes"
                          className="input"
                          value={serviceBillingPaymentForm.notes ?? ''}
                          onChange={(event) =>
                            setServiceBillingPaymentForm((previous) => ({
                              ...previous,
                              notes: event.target.value,
                            }))
                          }
                          disabled={!selectedServiceBillingArrearsRow || isMutatingServiceBilling}
                        >
                          <option value="">-- Pilih Metode --</option>
                          <option value="Cash">Cash</option>
                          <option value="BCA">BCA</option>
                          <option value="BRI">BRI</option>
                          <option value="MANDIRI">MANDIRI</option>
                          <option value="BNI">BNI</option>
                          <option value="QRIS">QRIS</option>
                          <option value="Lainnya">Lainnya</option>
                        </select>
                      </div>

                      <div className="form-actions" style={{ alignSelf: 'end' }}>
                        <button
                          type="button"
                          className="button button--success"
                          onClick={() => void handleQuickServicePayment()}
                          disabled={
                            !selectedServiceBillingArrearsRow ||
                            isMutatingServiceBilling ||
                            serviceBillingPaymentForm.amount <= 0
                          }
                        >
                          {isMutatingServiceBilling
                            ? 'Menyimpan Pembayaran...'
                            : 'Simpan Pembayaran'}
                        </button>
                      </div>
                    </div>

                    <p className="field-hint">
                      {selectedServiceBillingArrearsRow
                        ? `Sisa tagihan (belum lunas) saat ini: ${formatCurrency(selectedServiceBillingArrearsRow.totalOutstanding)}.`
                        : 'Pilih anak belum lunas untuk mulai pembayaran.'}{' '}
                      Nominal pas akan membuat tagihan otomatis lunas; jika kurang, sisa tagihan otomatis berkurang.
                    </p>
                    <p className="field-hint">
                      Aturan paket: harian dihitung per 24 jam. Paket 2 mingguan dihitung 10 hari,
                      hari ke-11 s.d. 15 dihitung harian, dan pada hari ke-16 otomatis migrasi ke
                      bulanan bila belum lunas.
                    </p>
                  </div>
                </details>
              </div>

              <div className="card service-billing-arrears-card">
                <h3>Daftar Pembayaran LUNAS</h3>
                <p className="card__description">
                  Menampilkan daftar anak yang pembayarannya sudah berstatus <strong>LUNAS</strong> beserta total nominal yang disetorkan pada periode aktif. Seluruh kelas digabung dan diurutkan.
                </p>

                <div className="form-grid form-grid--3" style={{ marginBottom: '1.5rem' }}>
                  <div className="field-group">
                    <label className="label">Bulan</label>
                    <input
                      className="input"
                      type="month"
                      value={serviceBillingPaidMonth}
                      onChange={(e) => setServiceBillingPaidMonth(e.target.value)}
                    />
                  </div>
                  <div className="field-group">
                    <label className="label">Kategori Paket</label>
                    <select
                      className="input"
                      value={serviceBillingPaidPackage}
                      onChange={(e) => setServiceBillingPaidPackage(e.target.value as ServicePackage | '')}
                    >
                      <option value="">Semua Paket</option>
                      {servicePackageOptions.map(opt => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </select>
                  </div>
                  <div className="field-group">
                    <label className="label">Jumlah Data</label>
                    <select
                      className="input"
                      value={serviceBillingPaidLimit}
                      onChange={(e) => setServiceBillingPaidLimit(Number(e.target.value))}
                    >
                      <option value={20}>20 Data</option>
                      <option value={50}>50 Data</option>
                      <option value={100}>100 Data</option>
                      <option value={9999}>Semua Data</option>
                    </select>
                  </div>
                </div>

                <div className="table-wrap">
                  <table className="table service-billing-arrears-table">
                    <thead>
                      <tr>
                        <th>Nama Anak</th>
                        <th>Paket</th>
                        <th style={{ textAlign: 'center' }}>Status</th>
                        <th style={{ textAlign: 'center' }}>Total Dibayarkan</th>
                      </tr>
                    </thead>
                    <tbody>
                      {isLoadingServiceBilling && serviceBillingPaidRows.length === 0 ? (
                        <tr><td colSpan={4} className="table__empty">Memuat daftar lunas...</td></tr>
                      ) : serviceBillingPaidRows.length === 0 ? (
                        <tr><td colSpan={4} className="table__empty">Tidak ada anak yang sudah lunas.</td></tr>
                      ) : (
                        serviceBillingPaidRows.map((row) => (
                          <tr key={row.childId}>
                            <td>
                              <div className="service-billing-package-name">
                                <strong>{row.childName}</strong>
                                {row.isMigrated && <span className="service-billing-migration-badge">Migrasi</span>}
                              </div>
                            </td>
                            <td>{row.packageLabel}</td>
                            <td style={{ textAlign: 'center' }}>
                              <span style={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                padding: '4px 12px',
                                fontSize: '0.85rem',
                                fontWeight: 'bold',
                                color: '#fff',
                                backgroundColor: 'var(--color-success, #38a169)',
                                borderRadius: '9999px',
                              }}>LUNAS</span>
                            </td>
                            <td style={{ textAlign: 'center' }}>{formatCurrency(row.paidAmount)}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          )

        default:
          return null
      }
    }

    if (activeSidebar === 'data-anak') {
      if (isLoadingServices) {
        return (
          <section className="page">
            <div className="card">
              <p>Memuat data anak...</p>
            </div>
          </section>
        )
      }

      return (
        <DataAnakPage
          childrenData={appData.children}
          viewerRole="ADMIN"
          canManageData
          onSave={upsertChildProfileAdmin}
          onDelete={removeChildProfileAdmin}
          onRequestConfirm={requestConfirm}
        />
      )
    }

    // Settings tabs
    switch (settingsTab) {
      case 'petugas':
        return (
          <section className="page">
            <div className="card">
              <h2>{editingStaffId ? 'Edit Akun Petugas' : 'Tambah Akun Petugas'}</h2>
              <p className="card__description">{staffCountLabel} terdaftar</p>

              <form onSubmit={handleSubmitStaff}>
                <div className="form-grid form-grid--3">
                  <div className="field-group">
                    <label className="label" htmlFor="staffFullName">
                      Nama Lengkap
                    </label>
                    <input
                      id="staffFullName"
                      className="input"
                      value={staffForm.fullName}
                      onChange={(event) =>
                        setStaffForm((previous) => ({
                          ...previous,
                          fullName: event.target.value,
                        }))
                      }
                    />
                  </div>

                  <div className="field-group">
                    <label className="label" htmlFor="staffEmail">
                      Email
                    </label>
                    <input
                      id="staffEmail"
                      className="input"
                      type="email"
                      value={staffForm.email}
                      onChange={(event) =>
                        setStaffForm((previous) => ({
                          ...previous,
                          email: event.target.value,
                        }))
                      }
                    />
                  </div>

                  <div className="field-group">
                    <label className="label" htmlFor="staffPassword">
                      {editingStaffId ? 'Password Baru (Opsional)' : 'Password'}
                    </label>
                    <div className="input-with-action">
                      <input
                        id="staffPassword"
                        className="input"
                        type={showStaffPassword ? 'text' : 'password'}
                        value={staffForm.password}
                        onChange={(event) =>
                          setStaffForm((previous) => ({
                            ...previous,
                            password: event.target.value,
                          }))
                        }
                      />
                      <button
                        type="button"
                        className="icon-button"
                        onClick={() => setShowStaffPassword((previous) => !previous)}
                        aria-label={showStaffPassword ? 'Sembunyikan password' : 'Tampilkan password'}
                      >
                        {showStaffPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="form-grid form-grid--2">
                  <div className="field-group">
                    <label className="label" htmlFor="staffTanggalMasuk">
                      Tanggal Masuk
                    </label>
                    <input
                      id="staffTanggalMasuk"
                      className="input"
                      type="date"
                      value={staffForm.tanggalMasuk}
                      onChange={(event) =>
                        setStaffForm((previous) => ({
                          ...previous,
                          tanggalMasuk: event.target.value,
                        }))
                      }
                    />
                  </div>

                  <div className="field-group field-group--small">
                    <label className="label" htmlFor="staffStatus">
                      Status Akun
                    </label>
                  <select
                    id="staffStatus"
                    className="input"
                    value={staffForm.isActive ? 'aktif' : 'nonaktif'}
                    onChange={(event) =>
                      setStaffForm((previous) => ({
                        ...previous,
                        isActive: event.target.value === 'aktif',
                      }))
                    }
                  >
                    <option value="aktif">Aktif</option>
                    <option value="nonaktif">Nonaktif</option>
                  </select>
                  </div>
                </div>

                <div className="form-actions">
                  <button type="submit" className="button">
                    {editingStaffId ? 'Update Petugas' : 'Simpan Petugas'}
                  </button>
                  {editingStaffId ? (
                    <button
                      type="button"
                      className="button button--ghost"
                      onClick={resetStaffForm}
                    >
                      Batal Edit
                    </button>
                  ) : null}
                </div>
              </form>
            </div>

            <div className="card">
              <h3>Daftar Petugas</h3>
              <div className="table-wrap">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Nama</th>
                      <th>Email</th>
                      <th>Status</th>
                      <th>Tanggal Masuk</th>
                      <th>Masa Kerja</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {isLoadingStaff ? (
                      <tr>
                        <td colSpan={6} className="table__empty">
                          Memuat data petugas...
                        </td>
                      </tr>
                    ) : staffUsers.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="table__empty">
                          Belum ada data petugas.
                        </td>
                      </tr>
                    ) : (
                      staffUsers.map((staff) => (
                        <tr key={staff.id}>
                          <td>{staff.fullName}</td>
                          <td>{staff.email}</td>
                          <td>{staff.isActive ? 'Aktif' : 'Nonaktif'}</td>
                          <td>{formatDateOnly(staff.createdAt)}</td>
                          <td>{calculateServiceLength(staff.createdAt)}</td>
                          <td>
                            <div className="table-actions">
                              <button
                                type="button"
                                className="button button--tiny button--ghost"
                                onClick={() => startEditStaff(staff)}
                              >
                                Edit
                              </button>
                              <button
                                type="button"
                                className="button button--tiny button--danger"
                                onClick={() => void handleDeleteStaff(staff)}
                              >
                                Hapus
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </section>
        )

      case 'logs':
        return (
          <section className="page">
            <div className="card">
              <h2>Log Aktivitas Sistem</h2>
              <div className="form-grid form-grid--3">
                <div className="field-group">
                  <label className="label" htmlFor="logSearch">
                    Cari Log
                  </label>
                  <input
                    id="logSearch"
                    className="input"
                    placeholder="gmail / role / aksi / target / detail"
                    value={searchLogs}
                    onChange={(event) => setSearchLogs(event.target.value)}
                  />
                </div>
                <div className="field-group field-group--small">
                  <label className="label" htmlFor="logLimit">
                    Jumlah Data
                  </label>
                  <select
                    id="logLimit"
                    className="input"
                    value={activityLogLimit}
                    onChange={(event) => handleActivityLogLimitChange(event.target.value)}
                  >
                    {ACTIVITY_LOG_LIMIT_OPTIONS.map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-actions admin-log-filter-actions">
                  <button
                    type="button"
                    className="button"
                    onClick={() => void loadLogs(searchLogs)}
                    disabled={isLoadingLogs}
                  >
                    Terapkan Filter
                  </button>
                </div>
              </div>

              <div className="table-wrap">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Waktu</th>
                      <th>Gmail</th>
                      <th>Role</th>
                      <th>Aksi</th>
                      <th>Target</th>
                      <th>Detail</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {isLoadingLogs ? (
                      <tr>
                        <td colSpan={7} className="table__empty">
                          Memuat log aktivitas...
                        </td>
                      </tr>
                    ) : activityLogs.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="table__empty">
                          Belum ada log aktivitas.
                        </td>
                      </tr>
                    ) : (
                      activityLogs.map((entry) => {
                        const formatted = formatLogDateTimeParts(entry.eventAt)
                        return (
                          <tr key={entry.id}>
                            <td className="admin-log-time-cell">
                              <span className="admin-log-time-cell__date">{formatted.date}</span>
                              <span className="admin-log-time-cell__time">{formatted.time} WIB</span>
                            </td>
                            <td>{entry.gmail || '-'}</td>
                            <td>{entry.role || '-'}</td>
                            <td>{entry.action || '-'}</td>
                            <td>{entry.target || '-'}</td>
                            <td>{entry.detail || '-'}</td>
                            <td>{entry.status || '-'}</td>
                          </tr>
                        )
                      })
                    )}
                  </tbody>
                </table>
              </div>
              <div className="admin-log-pagination">
                <p className="field-hint admin-log-pagination__meta">
                  Halaman {activityLogPage} | Menampilkan {activityLogs.length} data | Limit{' '}
                  {activityLogLimit}
                </p>
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={handleLoadNextLogs}
                  disabled={isLoadingLogs || !activityLogHasMore || !activityLogNextCursor}
                >
                  Next
                </button>
              </div>
            </div>
          </section>
        )

      case 'backup':
        return (
          <section className="page">
            <div className="card">
              <h2>Backup Data</h2>
              <p className="card__description">
                Backup akan mengunduh snapshot JSON seluruh data utama aplikasi, termasuk
                akun admin/petugas, tarif layanan, dan log aktivitas.
              </p>
              <div className="form-actions">
                <button
                  type="button"
                  className="button button--success"
                  onClick={() => void handleBackup()}
                  disabled={isProcessingBackup}
                >
                  {isProcessingBackup ? 'Menyiapkan backup...' : 'Unduh Backup Sekarang'}
                </button>
              </div>
            </div>
          </section>
        )

      default:
        return null
    }
  }

  return (
    <div className="app-shell">
      <Sidebar
        activeMenu={activeSidebar}
        menus={adminMenus}
        isOpen={isSidebarOpen}
        onMenuSelect={selectMenu}
        onClose={() => setSidebarOpen(false)}
        onLogout={onLogout}
        userLabel={user.displayName}
        accountLabel="Akun Admin"
        panelTitle="Panel Admin"
        menuLabel="Menu Admin"
        chipLabel=""
      />

      <div className="app-main">
        <header className={`topbar ${isTopbarHidden ? 'is-hidden' : ''}`}>
          <button
            type="button"
            className="topbar__menu"
            onClick={() => setSidebarOpen(true)}
            aria-label="Buka menu"
          >
            <Menu size={18} />
          </button>
          <div>
            <h1>{activeHeader.title}</h1>
            <p>{activeHeader.subtitle}</p>
          </div>
        </header>

        <main className="app-content">
          {renderSubTabPills()}

          {errorMessage ? (
            <section className="page">
              <div className="card">
                <p className="field-error">{errorMessage}</p>
              </div>
            </section>
          ) : null}

          {renderContent()}
        </main>
      </div>

      {message ? (
        <div className="app-toast app-toast--success" role="status" aria-live="polite">
          <CheckCircle2 size={18} />
          <span>{message}</span>
        </div>
      ) : null}

      {isIncidentPdfDialogOpen ? (
        <div
          className="app-confirm-overlay"
          onClick={(event) => {
            if (event.target === event.currentTarget) {
              setIncidentPdfDialogOpen(false)
            }
          }}
        >
          <div className="app-confirm-dialog" role="dialog" aria-modal="true" style={{ maxWidth: '460px' }}>
            <h3>Unduh PDF Berita Acara</h3>
            <p>Pilih tipe unduhan per tanggal atau per bulan.</p>
            <div style={{ display: 'grid', gap: '0.75rem' }}>
              <div className="field-group">
                <label className="label">Tipe Unduhan</label>
                <select
                  className="input"
                  value={incidentPdfMode}
                  onChange={(event) => {
                    const nextMode = event.target.value as IncidentPdfMode
                    setIncidentPdfMode(nextMode)
                    if (nextMode === 'month') {
                      setIncidentPdfFilterDate('')
                    }
                  }}
                >
                  <option value="date">Per Tanggal</option>
                  <option value="month">Per Bulan</option>
                </select>
              </div>
              <div className="field-group">
                <label className="label">Bulan</label>
                <input
                  type="month"
                  className="input"
                  value={incidentPdfFilterMonth}
                  max={clampMonthKeyToToday(incidentPdfFilterMonth)}
                  onChange={(event) => {
                    const nextMonth = clampMonthKeyToToday(event.target.value)
                    setIncidentPdfFilterMonth(nextMonth)
                    if (incidentPdfFilterDate && !incidentPdfFilterDate.startsWith(nextMonth)) {
                      setIncidentPdfFilterDate('')
                    }
                  }}
                />
              </div>
              {incidentPdfMode === 'date' ? (
                <div className="field-group">
                  <label className="label">Tanggal</label>
                  <input
                    type="date"
                    className="input"
                    value={incidentPdfFilterDate}
                    min={incidentPdfDateBounds.min}
                    max={incidentPdfDateBounds.max}
                    onChange={(event) => setIncidentPdfFilterDate(clampOptionalDateKeyToToday(event.target.value))}
                  />
                </div>
              ) : null}
            </div>
            <div className="app-confirm-actions" style={{ marginTop: '1rem' }}>
              <button
                type="button"
                className="button button--ghost"
                onClick={() => setIncidentPdfDialogOpen(false)}
              >
                Batal
              </button>
              <button
                type="button"
                className="button"
                onClick={() => void handleDownloadIncidentPdf()}
                disabled={isDownloadingIncidentPdf}
              >
                {isDownloadingIncidentPdf ? 'Mengunduh...' : 'Unduh'}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {isStaffAttendancePdfDialogOpen ? (
        <div
          className="app-confirm-overlay"
          onClick={(event) => {
            if (event.target === event.currentTarget) {
              setStaffAttendancePdfDialogOpen(false)
            }
          }}
        >
          <div className="app-confirm-dialog" role="dialog" aria-modal="true" style={{ maxWidth: '460px' }}>
            <h3>Unduh PDF Kehadiran Petugas</h3>
            <p>Pilih data harian, bulanan, atau tahunan.</p>
            <div style={{ display: 'grid', gap: '0.75rem' }}>
              <div className="field-group">
                <label className="label">Tipe Unduhan</label>
                <select
                  className="input"
                  value={staffAttendancePdfMode}
                  onChange={(event) => setStaffAttendancePdfMode(event.target.value as StaffAttendancePdfMode)}
                >
                  <option value="daily">Harian</option>
                  <option value="monthly">Bulanan</option>
                  <option value="yearly">Tahunan</option>
                </select>
              </div>
              {staffAttendancePdfMode === 'daily' ? (
                <>
                  <div className="field-group">
                    <label className="label">Bulan</label>
                    <input
                      type="month"
                      className="input"
                      value={staffAttendanceFilterMonth}
                      max={clampMonthKeyToToday(staffAttendanceFilterMonth)}
                      onChange={(event) => handleStaffAttendanceMonthFilterChange(event.target.value)}
                    />
                  </div>
                  <div className="field-group">
                    <label className="label">Tanggal</label>
                    <input
                      type="date"
                      className="input"
                      value={staffAttendanceFilterDate}
                      min={getMonthDateBounds(staffAttendanceFilterMonth, todayIso).min}
                      max={getMonthDateBounds(staffAttendanceFilterMonth, todayIso).max}
                      onChange={(event) => handleStaffAttendanceDateFilterChange(event.target.value)}
                    />
                  </div>
                </>
              ) : null}
              {staffAttendancePdfMode === 'monthly' ? (
                <div className="field-group">
                  <label className="label">Bulan</label>
                  <input
                    type="month"
                    className="input"
                    value={staffAttendanceFilterMonth}
                    max={clampMonthKeyToToday(staffAttendanceFilterMonth)}
                    onChange={(event) => handleStaffAttendanceMonthFilterChange(event.target.value)}
                  />
                </div>
              ) : null}
              {staffAttendancePdfMode === 'yearly' ? (
                <div className="field-group">
                  <label className="label">Tahun</label>
                  <input
                    type="number"
                    className="input"
                    min={2000}
                    max={Number(todayIso.slice(0, 4))}
                    value={staffAttendancePdfYear}
                    onChange={(event) => setStaffAttendancePdfYear(event.target.value.replace(/[^\d]/g, '').slice(0, 4))}
                  />
                </div>
              ) : null}
            </div>
            <div className="app-confirm-actions" style={{ marginTop: '1rem' }}>
              <button
                type="button"
                className="button button--ghost"
                onClick={() => setStaffAttendancePdfDialogOpen(false)}
              >
                Batal
              </button>
              <button
                type="button"
                className="button"
                onClick={handleDownloadStaffAttendancePdf}
                disabled={isDownloadingStaffAttendancePdf}
              >
                {isDownloadingStaffAttendancePdf ? 'Mengunduh...' : 'Unduh'}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {confirmDialog ? (
        <div
          className="app-confirm-overlay"
          onClick={(event) => {
            if (event.target === event.currentTarget) {
              closeConfirmDialog(false)
            }
          }}
        >
          <div className="app-confirm-dialog" role="alertdialog" aria-modal="true">
            <h3>{confirmDialog.title}</h3>
            <p>{confirmDialog.message}</p>
            <div className="app-confirm-actions">
              <button
                type="button"
                className="button button--ghost"
                onClick={() => closeConfirmDialog(false)}
              >
                {confirmDialog.cancelLabel}
              </button>
              <button
                type="button"
                className={`button ${confirmDialog.tone === 'danger' ? 'button--danger' : ''}`}
                onClick={() => closeConfirmDialog(true)}
              >
                {confirmDialog.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {isSyncingAppData ? (
        <div className="app-loading-overlay" role="status" aria-live="polite">
          <div className="app-loading-dialog">
            <div className="app-loading-spinner" aria-hidden="true" />
            <p>Menyimpan perubahan...</p>
          </div>
        </div>
      ) : null}
    </div>
  )
}

export default AdminSection
