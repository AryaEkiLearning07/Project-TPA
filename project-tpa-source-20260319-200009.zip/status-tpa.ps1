$ErrorActionPreference = 'Stop'

$frontendPort = Get-NetTCPConnection -State Listen -LocalPort 5173 -ErrorAction SilentlyContinue
$backendPort = Get-NetTCPConnection -State Listen -LocalPort 4000 -ErrorAction SilentlyContinue

Write-Output "Frontend (5173): $([bool]$frontendPort)"
Write-Output "Backend  (4000): $([bool]$backendPort)"

try {
  $localHealth = Invoke-WebRequest -Uri 'http://127.0.0.1:4000/health' -UseBasicParsing -TimeoutSec 5
  Write-Output "Local backend health: $($localHealth.StatusCode)"
} catch {
  Write-Output 'Local backend health: DOWN'
}

try {
  $publicRoot = Invoke-WebRequest -Uri 'https://tparumahceria.my.id' -UseBasicParsing -TimeoutSec 10
  Write-Output "Public root: $($publicRoot.StatusCode)"
} catch {
  Write-Output 'Public root: DOWN'
}

