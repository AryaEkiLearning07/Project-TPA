$ErrorActionPreference = 'Stop'

param(
  [switch]$SkipBuild
)

$projectRoot = Split-Path -Parent $PSScriptRoot
$logFile = Join-Path $projectRoot 'runtime-prod.log'
$frontendPortNumber = 4173
$backendPortNumber = 4000

$frontendPort = Get-NetTCPConnection -State Listen -LocalPort $frontendPortNumber -ErrorAction SilentlyContinue
$backendPort = Get-NetTCPConnection -State Listen -LocalPort $backendPortNumber -ErrorAction SilentlyContinue

if ($frontendPort -and $backendPort) {
  Write-Output "TPA runtime production sudah berjalan ($frontendPortNumber & $backendPortNumber aktif)."
  exit 0
}

if (-not $SkipBuild) {
  Write-Output 'Menjalankan build frontend...'
  Push-Location $projectRoot
  try {
    npm run build
  } finally {
    Pop-Location
  }

  Write-Output 'Menjalankan build backend...'
  Push-Location (Join-Path $projectRoot 'server')
  try {
    npm run build
  } finally {
    Pop-Location
  }
}

$existingBackendStarter = Get-CimInstance Win32_Process |
  Where-Object {
    $_.Name -eq 'cmd.exe' -and
    $_.CommandLine -match [regex]::Escape("$projectRoot\\server && npm run start")
  }

if (-not $existingBackendStarter) {
  Start-Process -FilePath 'cmd.exe' `
    -ArgumentList "/c cd /d `"$projectRoot\server`" && npm run start >> `"$logFile`" 2>&1" `
    -WindowStyle Hidden
}

$existingFrontendStarter = Get-CimInstance Win32_Process |
  Where-Object {
    $_.Name -eq 'cmd.exe' -and
    $_.CommandLine -match [regex]::Escape("$projectRoot && npm run preview -- --host 0.0.0.0 --port $frontendPortNumber")
  }

if (-not $existingFrontendStarter) {
  Start-Process -FilePath 'cmd.exe' `
    -ArgumentList "/c cd /d `"$projectRoot`" && npm run preview -- --host 0.0.0.0 --port $frontendPortNumber >> `"$logFile`" 2>&1" `
    -WindowStyle Hidden
}

Start-Sleep -Seconds 8

$frontendPort = Get-NetTCPConnection -State Listen -LocalPort $frontendPortNumber -ErrorAction SilentlyContinue
$backendPort = Get-NetTCPConnection -State Listen -LocalPort $backendPortNumber -ErrorAction SilentlyContinue

if (-not ($frontendPort -and $backendPort)) {
  Write-Error "Gagal menyalakan runtime production TPA. Cek $logFile."
}

Write-Output "TPA runtime production berhasil dinyalakan (frontend:$frontendPortNumber, backend:$backendPortNumber)."

